# -*- coding: utf-8 -*-
"""Chạy giả lập thế giới không cần màn hình: chiến đấu, cơ quan, nhiệm vụ, hồi sinh."""
import math
import os
import random
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from trutien import data as D      # noqa: E402
from trutien.player import Player  # noqa: E402
from trutien.world import World    # noqa: E402


def bot_step(w, dt):
    """Bot đơn giản: lại gần quái gần nhất, đánh, dùng kỹ năng và đan dược."""
    p = w.p
    if p.dead:
        w.respawn()
        w.travel("rung_truc", (300, 560))
        return
    if p.hp < p.stats["max_hp"] * 0.4:
        w.use_potion()
    tgt = w.nearest_monster(p.x, p.y, 900)
    mv = (0.0, 0.0)
    if tgt:
        d = math.hypot(tgt.x - p.x, tgt.y - p.y)
        if d > 45:
            mv = ((tgt.x - p.x) / d, (tgt.y - p.y) / d)
        w.player_attack()
        for i in (1, 0, 3, 2):
            w.cast(i)
    w.update(dt, mv)


class TestWorld(unittest.TestCase):
    def make(self, seed=1, level=1):
        p = Player("Bot")
        if level > 1:
            p.gain_exp(10 ** 6)
            p.level = level
            p.recalc()
            p.hp, p.mp = p.stats["max_hp"], p.stats["max_mp"]
        w = World(p, random.Random(seed))
        return p, w

    def test_maps_built(self):
        p, w = self.make()
        self.assertEqual(len(w.maps["rung_truc"].monsters), 9 + 7 + 1 + 1)
        self.assertEqual(len(w.maps["u_coc"].monsters), 8 + 1)
        self.assertEqual(len(w.maps["dai_truc_phong"].monsters), 0)
        # quái không bị kẹt trong vật cản lúc sinh ra
        for key, mp in w.maps.items():
            w.cur = mp
            for m in mp.monsters:
                self.assertFalse(w._blocked(m.x, m.y, m.radius * 0.8), (key, m.mid, m.x, m.y))

    def test_bot_farms_forest(self):
        p, w = self.make(seed=3)
        w.travel("rung_truc", (300, 560))
        for _ in range(int(600 / 0.05)):
            bot_step(w, 0.05)
        self.assertGreater(p.kills, 20)
        self.assertGreater(p.level, 3)
        self.assertGreaterEqual(p.gold, 60)
        self.assertTrue(p.inventory or sum(p.gems.values()) > 0)

    def test_portals_roundtrip(self):
        p, w = self.make()
        p.x, p.y = 1170, 400                      # trong cổng sang Rừng Trúc
        w.update(0.016)
        self.assertEqual(p.map, "rung_truc")
        self.assertEqual(w.cur.key, "rung_truc")
        # đi bộ sang trái vào cổng về làng
        p.x, p.y = 20, 560
        w.update(0.016)
        self.assertEqual(p.map, "dai_truc_phong")

    def test_wall_blocks_player(self):
        p, w = self.make()
        w.travel("u_coc", (700, 800))
        p.x, p.y = 700, 460
        for _ in range(200):
            w.update(0.05, (0, -1))
        self.assertGreater(p.y, 420, "người chơi xuyên qua cửa đá khi chưa mở")

    def test_puzzle_order(self):
        p, w = self.make()
        p.quests.accept("m1", 1)
        w.travel("u_coc", (700, 800))
        m = w.cur
        door = m.door
        sw = m.switches
        # sai thứ tự
        p.x, p.y = sw[1]["x"], sw[1]["y"]
        w.interact()
        self.assertFalse(sw[1]["on"])
        self.assertFalse(m.solved)
        # đúng thứ tự
        for i in (0, 1, 2):
            p.x, p.y = sw[i]["x"], sw[i]["y"]
            w.interact()
        self.assertTrue(m.solved)
        self.assertNotIn(door, m.obstacles)
        # đi xuyên được qua cửa đã mở
        p.x, p.y = 700, 470
        for _ in range(80):
            w.update(0.05, (0, -1))
        self.assertLess(p.y, 400)

    def test_puzzle_quest_completes(self):
        p, w = self.make(level=4)
        q = p.quests
        for qid in ("m1", "m2"):
            q.state[qid] = {"status": "done", "n": 1}
        q.accept("s3", 4)
        w.travel("u_coc", (700, 800))
        for i in (0, 1, 2):
            p.x, p.y = w.cur.switches[i]["x"], w.cur.switches[i]["y"]
            w.interact()
        self.assertEqual(q.status("s3", 4), "ready")

    def test_puzzle_already_solved_before_accept(self):
        p, w = self.make(level=4)
        q = p.quests
        for qid in ("m1", "m2"):
            q.state[qid] = {"status": "done", "n": 1}
        w.travel("u_coc", (700, 800))
        for i in (0, 1, 2):
            p.x, p.y = w.cur.switches[i]["x"], w.cur.switches[i]["y"]
            w.interact()
        q.accept("s3", 4)
        w.notify_quest_accepted("s3")
        self.assertEqual(q.status("s3", 4), "ready")

    def test_talk_quest_via_interact(self):
        p, w = self.make()
        p.quests.accept("m1", 1)
        n = [x for x in w.cur.npcs if x["id"] == "thuong_nhan"][0]
        p.x, p.y = n["x"] + 20, n["y"]
        res = w.interact()
        self.assertEqual(res[0], "npc")
        self.assertEqual(p.quests.status("m1", 1), "ready")

    def test_kill_boss_drops_and_quest(self):
        p, w = self.make(seed=5, level=15)
        for qid in ("m1", "m2"):
            p.quests.state[qid] = {"status": "done", "n": 1}
        p.quests.accept("m3", 15)
        w.travel("u_coc", (700, 300))
        boss = [m for m in w.cur.monsters if m.mid == "yeu_thu_u_coc"][0]
        p.x, p.y = boss.x, boss.y + 70
        before = sum(p.gems.values())
        for _ in range(int(120 / 0.05)):
            if boss.dead:
                break
            if p.dead:
                w.respawn()
                w.travel("u_coc", (700, 300))
            if p.hp < p.stats["max_hp"] * 0.4:
                w.use_potion()
                p.potions = max(p.potions, 5)
            d = math.hypot(boss.x - p.x, boss.y - p.y)
            w.player_attack()
            for i in (1, 0, 3, 2):
                w.cast(i)
            p.hp = max(p.hp, p.stats["max_hp"] * 0.3)       # tập trung kiểm tra rơi đồ, không cân bằng
            w.update(0.05, (0, 0) if d < 60 else ((boss.x - p.x) / d, (boss.y - p.y) / d))
        self.assertTrue(boss.dead, "boss không bị hạ")
        purple_items = [i for i in p.inventory if i.tier == 3]
        self.assertTrue(1 <= len(purple_items) <= 2, "BHK phải rơi 1-2 đồ Tím")
        self.assertGreaterEqual(p.gems["white"], 3)
        self.assertGreaterEqual(p.gems["gold"], 2)
        self.assertGreaterEqual(p.gems["purple"], 1)
        self.assertEqual(p.quests.status("m3", 15), "ready")
        self.assertGreater(sum(p.gems.values()), before)
        self.assertGreaterEqual(len([i for i in p.inventory if i.tier == 1]), 2)

    def test_death_and_respawn(self):
        p, w = self.make()
        w.travel("rung_truc", (300, 560))
        w._damage_player(10 ** 6)
        self.assertTrue(p.dead)
        w.update(0.05)
        w.respawn()
        self.assertFalse(p.dead)
        self.assertEqual(p.map, D.HUB_MAP)
        self.assertGreater(p.hp, 0)

    def test_skills_unlock_by_level(self):
        p, w = self.make()
        self.assertFalse(w.cast(3))               # Huyền Hỏa Trận mở ở cấp 8
        p.gain_exp(10 ** 6)
        p.hp, p.mp = p.stats["max_hp"], p.stats["max_mp"]
        self.assertTrue(w.cast(3))
        self.assertFalse(w.cast(3))               # đang hồi chiêu

    def test_potion(self):
        p, w = self.make()
        self.assertFalse(w.use_potion())          # đầy máu thì không dùng
        p.hp = 10
        self.assertTrue(w.use_potion())
        self.assertEqual(p.potions, 2)
        self.assertFalse(w.use_potion())          # đang hồi


if __name__ == "__main__":
    unittest.main()
