# -*- coding: utf-8 -*-
"""Giả lập pygame vừa đủ để chạy thử toàn bộ code giao diện khi máy không có pygame."""
import sys
import types


class _Any:
    def __init__(self, *a, **k):
        pass

    def __call__(self, *a, **k):
        return _Any()

    def __getattr__(self, n):
        return _Any()

    def get_width(self):
        return 40

    def get_height(self):
        return 16

    def __iter__(self):
        return iter(())

    def __getitem__(self, i):
        return 0

    def __bool__(self):
        return False


class _Keys:
    def __init__(self, down=()):
        self.down = set(down)

    def __getitem__(self, k):
        return k in self.down


class FakePygame(types.ModuleType):
    def __init__(self):
        super().__init__("pygame")
        self._codes = {}
        self.pressed = set()
        self.events = []
        self.mouse_pos = (0, 0)
        self.draw = _Any()
        self.font = _Any()
        self.display = types.SimpleNamespace(flip=lambda: None, set_caption=lambda s: None,
                                             set_mode=lambda sz: _Any())
        self.mouse = types.SimpleNamespace(get_pos=lambda: self.mouse_pos)
        self.key = types.SimpleNamespace(get_pressed=lambda: _Keys(self.pressed))
        self.event = types.SimpleNamespace(get=self._get)
        self.time = _Any()
        self.init = lambda: None
        self.quit = lambda: None
        self.Surface = _Any

    def _get(self):
        ev, self.events = self.events, []
        return ev

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        if name.isupper() or name.startswith("K_"):
            if name not in self._codes:
                self._codes[name] = 1000 + len(self._codes)
            return self._codes[name]
        return _Any()


def install():
    fake = FakePygame()
    sys.modules["pygame"] = fake
    return fake
