# -*- coding: utf-8 -*-
"""Chạy thử giao diện bằng pygame giả: bắt lỗi chính tả biến, sai tên hàm, sai kiểu dữ liệu."""
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
os.environ["TRUTIEN_SAVE_DIR"] = tempfile.mkdtemp()

try:
    import pygame as _real
    REAL = hasattr(_real, "Rect") and hasattr(_real, "SRCALPHA")
except Exception:
    REAL = False
import fake_pygame
FAKE = fake_pygame.install()

from trutien import game as GM          # noqa: E402
from trutien import data as D           # noqa: E402
from trutien import items as I          # noqa: E402
import random                           # noqa: E402


def ev(kind, **kw):
    return types.SimpleNamespace(type=kind, **kw)


class Smoke(unittest.TestCase):
    def setUp(self):
        FAKE.pressed = set()
        FAKE.mouse_pos = (0, 0)
        self.g = GM.Game(FAKE.display.set_mode((1024, 640)))

    def frame(self, n=1, dt=0.016):
        for _ in range(n):
            for e in FAKE.events:
                pass
            for e in FAKE._get():
                self.g.handle_event(e)
            self.g.update(dt)
            self.g.draw()

    def key(self, name):
        self.g.handle_event(ev(FAKE.KEYDOWN, key=getattr(FAKE, name)))

    def click_button(self, label_part=None, index=None):
        """Bấm nút thứ index trong danh sách nút của khung hình hiện tại."""
        self.frame()
        rect, cb, en = self.g.ui.buttons[index]
        cb()

    def test_menu_to_game_and_all_panels(self):
        g = self.g
        self.frame(3)                                   # menu
        g.start_name()
        self.frame()
        g.handle_event(ev(FAKE.TEXTINPUT, text="Lâm"))
        g.handle_event(ev(FAKE.TEXTINPUT, text="Phong"))
        self.assertEqual(g.name_buf, "LâmPhong")
        self.key("K_BACKSPACE")
        self.key("K_RETURN")
        self.assertEqual(g.state, "play")
        self.frame(5)
        # di chuyển + đánh
        FAKE.pressed = {FAKE.K_d, FAKE.K_j}
        self.frame(30)
        FAKE.pressed = set()
        for k in ("K_1", "K_2", "K_3", "K_4", "K_f", "K_r"):
            self.key(k)
            self.frame()
        # mở các bảng
        for k in ("K_i", "K_q", "K_ESCAPE"):
            self.key(k)
            self.frame(2)
            self.key(k if k != "K_ESCAPE" else "K_ESCAPE")
            self.frame()
        self.assertIsNone(g.panel)

    def test_inventory_actions(self):
        g = self.g
        g.new_game("Test")
        p = g.p
        rng = random.Random(5)
        for t in (0, 1, 1, 2, 3):
            p.inventory.append(I.generate(t, 5, rng))
        p.gems = {"white": 10, "gold": 10, "purple": 10}
        self.key("K_i")
        self.frame()
        g.select(p.inventory[0])
        self.frame()
        g.do_equip()
        g.select(p.equipment[g.sel.slot])
        self.frame()
        for gem in D.GEM_KINDS:
            g.do_upgrade(gem)
        g.do_exchange("white")
        g.do_exchange("gold")
        g.toggle_auto_sell()
        g.do_unequip()
        self.frame(3)
        g.scroll = 99
        self.frame()
        for it in list(p.inventory):
            g.select(it)
            self.frame()

    def test_dialog_and_quests(self):
        g = self.g
        g.new_game("Test")
        w, p = g.world, g.p
        p.x, p.y = 520, 330 + 30                       # gần Điền Bất Dịch
        self.key("K_e")
        self.assertEqual(g.panel, "dialog")
        self.frame()
        g.accept_quest("m1")
        self.frame()
        self.key("K_e")                                # đóng
        p.x, p.y = 700, 460 + 30                       # gần Thương Nhân
        self.key("K_e")
        self.frame()
        w.interact()
        self.assertEqual(p.quests.status("m1", p.level), "ready")
        g.turn_in("m1")
        p.inventory += [I.generate(0, 1, random.Random(1)), I.generate(1, 1, random.Random(2))]
        g.buy_potion()
        g.sell_tier(0)
        g.sell_tier(1)
        self.frame(2)
        self.key("K_q")
        self.frame(2)

    def test_save_load_roundtrip_and_other_maps(self):
        g = self.g
        g.new_game("Test")
        for key in ("rung_truc", "u_coc"):
            g.world.travel(key, D.MAPS[key]["portals"][0]["spawn"])
            for _ in range(20):
                self.frame()
        g.world.cur.monsters[0].aggro = True
        g.world.cur.monsters[-1].shock_t = 1.0
        self.frame(3)
        g.to_menu()
        self.frame()
        g.continue_game()
        self.assertEqual(g.state, "play")
        self.frame(5)
        g.p.dead = True
        self.frame(2)
        g.world.respawn()
        self.key("K_ESCAPE")
        self.frame()
        g.save_click()
        g.quit_save()
        self.assertFalse(g.running)


if __name__ == "__main__":
    unittest.main()
