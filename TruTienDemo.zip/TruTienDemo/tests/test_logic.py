# -*- coding: utf-8 -*-
"""Kiểm thử logic lõi (không cần pygame)."""
import os
import random
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from trutien import data as D          # noqa: E402
from trutien import gems, items, loot, save  # noqa: E402
from trutien.player import Player      # noqa: E402
from trutien.quests import QuestLog    # noqa: E402


class AlwaysHigh(random.Random):
    """RNG luôn trả 0.9999: không có lần tung nào trúng theo xác suất."""
    def random(self):
        return 0.9999


class TestItems(unittest.TestCase):
    def test_affix_counts_by_tier(self):
        rng = random.Random(1)
        for tier in range(4):
            lo, hi = D.AFFIX_COUNT[tier]
            for _ in range(300):
                it = items.generate(tier, 5, rng)
                self.assertTrue(lo <= len(it.affixes) <= hi, (tier, len(it.affixes)))
                keys = [k for k, _ in it.affixes]
                self.assertEqual(len(keys), len(set(keys)), "dòng chỉ số bị trùng")
                self.assertEqual(it.special is not None, tier == 3)

    def test_purple_lines_stronger_than_green(self):
        rng = random.Random(2)
        for key, (_, lo, hi, _) in D.AFFIXES.items():
            green_max = hi * D.AFFIX_TIER_MULT[1]
            purple_min = (lo + (hi - lo) * 0.5) * D.AFFIX_TIER_MULT[3]
            self.assertGreater(purple_min, lo * D.AFFIX_TIER_MULT[1])
            self.assertGreater(purple_min * 1.0, (lo + hi) / 2 * 1.0, key)
            self.assertGreater(D.AFFIX_TIER_MULT[3] * hi, green_max)

    def test_upgrade_scaling(self):
        it = items.generate(2, 3, random.Random(3))
        s0 = it.stats()
        it.plus = 9
        s9 = it.stats()
        for k in s0:
            self.assertAlmostEqual(s9[k], s0[k] * (1 + 0.05 * 9), places=6)
        p = items.generate(3, 3, random.Random(3))
        p.plus = 9
        self.assertAlmostEqual(p.factor(), 1 + 0.06 * 9)
        v0 = items.Item("x", "ring", 3, 1, {}, [], "loi_phat", 0).special_value()
        v3 = items.Item("x", "ring", 3, 1, {}, [], "loi_phat", 3).special_value()
        v9 = items.Item("x", "ring", 3, 1, {}, [], "loi_phat", 9).special_value()
        self.assertLess(v0, v3)
        self.assertLess(v3, v9)
        self.assertAlmostEqual(v9, v0 * 2.5)


class TestLoot(unittest.TestCase):
    N = 120000

    def _rates(self, kind, n=None):
        n = n or self.N
        rng = random.Random(42)
        pity = {"gold": 0, "purple": 0}
        tier_items = [0] * 4
        tier_kills = [0] * 4
        gem_kills = {g: 0 for g in D.GEM_KINDS}
        gem_total = {g: 0 for g in D.GEM_KINDS}
        for _ in range(n):
            pity_before = dict(pity)
            d = loot.roll_drops(kind, 5, 0, pity, rng)
            for t in range(4):
                c = sum(1 for i in d.items if i.tier == t)
                tier_items[t] += c
                tier_kills[t] += 1 if c else 0
            for g in D.GEM_KINDS:
                if d.gems[g]:
                    gem_kills[g] += 1
                gem_total[g] += d.gems[g]
        return tier_items, tier_kills, gem_kills, gem_total

    def test_boss_tables(self):
        # Boss thường: Xanh 100% (2-5), Vàng ~50% (1-2), Tím ~20%
        n = 30000
        ti, tk, gk, gt = self._rates(D.BOSS, n)
        self.assertEqual(tk[1], n)
        self.assertAlmostEqual(ti[1] / n, 3.5, delta=0.05)
        self.assertAlmostEqual(tk[2] / n, 0.50, delta=0.02)
        self.assertAlmostEqual(tk[3] / n, 0.20, delta=0.02)
        self.assertAlmostEqual(gk["white"] / n, 0.95, delta=0.02)
        self.assertAlmostEqual(gk["gold"] / n, 0.80, delta=0.02)
        self.assertAlmostEqual(gk["purple"] / n, 0.40, delta=0.02)
        self.assertAlmostEqual(gt["white"] / n, 0.95 * 2, delta=0.06)

    def test_bhk_tables(self):
        n = 30000
        ti, tk, gk, gt = self._rates(D.BHK, n)
        self.assertEqual(tk[3], n)                         # Tím 100%
        self.assertAlmostEqual(ti[3] / n, 1.5, delta=0.03)  # 1-2 món
        self.assertEqual(gk["white"], n)
        self.assertEqual(gk["gold"], n)
        self.assertEqual(gk["purple"], n)
        self.assertAlmostEqual(gt["white"] / n, 4.0, delta=0.03)   # 3-5
        self.assertAlmostEqual(gt["gold"] / n, 3.0, delta=0.03)    # 2-4
        self.assertAlmostEqual(gt["purple"] / n, 1.5, delta=0.03)  # 1-2

    def test_normal_and_elite_gem_rates(self):
        ti, tk, gk, gt = self._rates(D.QT)
        self.assertAlmostEqual(gk["white"] / self.N, 0.10, delta=0.005)
        self.assertAlmostEqual(gk["gold"] / self.N, 0.05, delta=0.004)
        self.assertAlmostEqual(tk[1] / self.N, 0.10, delta=0.005)
        self.assertAlmostEqual(tk[0] / self.N, 0.60, delta=0.01)
        ti, tk, gk, gt = self._rates(D.TA, 60000)
        self.assertAlmostEqual(gk["white"] / 60000, 0.30, delta=0.01)
        self.assertAlmostEqual(gk["gold"] / 60000, 0.15, delta=0.01)
        self.assertAlmostEqual(gk["purple"] / 60000, 0.05, delta=0.008)
        self.assertAlmostEqual(tk[1] / 60000, 0.50, delta=0.01)

    def test_pity_gold_after_60_normal_kills(self):
        rng = AlwaysHigh()
        pity = {"gold": 0, "purple": 0}
        gold_at = []
        for i in range(1, 121):
            d = loot.roll_drops(D.QT, 3, 0, pity, rng)
            if any(it.tier == 2 for it in d.items):
                gold_at.append(i)
        self.assertEqual(gold_at, [60, 120])

    def test_pity_purple_after_1500(self):
        rng = AlwaysHigh()
        pity = {"gold": 0, "purple": 0}
        purple_at = []
        for i in range(1, 1501):
            d = loot.roll_drops(D.QT, 3, 0, pity, rng)
            if any(it.tier == 3 for it in d.items):
                purple_at.append(i)
        self.assertEqual(purple_at, [1500])

    def test_elite_counts_as_ten(self):
        rng = AlwaysHigh()
        pity = {"gold": 0, "purple": 0}
        hits = []
        for i in range(1, 13):
            d = loot.roll_drops(D.TA, 3, 0, pity, rng)
            if any(it.tier == 2 for it in d.items):
                hits.append(i)
        self.assertEqual(hits, [6, 12])          # 6 tinh anh = 60 điểm

    def test_pity_resets_on_natural_drop(self):
        rng = random.Random(5)
        pity = {"gold": 59, "purple": 0}
        # ép rơi tự nhiên: dùng BHK (Tím 100%) để xem Tím reset, Vàng không bị ảnh hưởng nếu không rơi
        pity["purple"] = 700
        loot.roll_drops(D.BHK, 3, 0, pity, rng)
        self.assertEqual(pity["purple"], 0)

    def test_luck_is_capped(self):
        rng = random.Random(9)
        pity = {"gold": 0, "purple": 0}
        n = 40000
        got = sum(1 for _ in range(n)
                  if any(i.tier == 1 for i in loot.roll_drops(D.QT, 3, 500, pity, rng).items))
        self.assertAlmostEqual(got / n, 0.10 * 1.25, delta=0.008)


class TestGems(unittest.TestCase):
    def test_total_cost(self):
        self.assertEqual(sum(D.UPGRADE_COST["white"]), 18)
        self.assertEqual(sum(D.UPGRADE_COST["gold"]), 15)
        self.assertEqual(sum(D.UPGRADE_COST["purple"]), 9)
        self.assertEqual(D.UPGRADE_COST["white"], [1, 1, 1, 2, 2, 2, 3, 3, 3])
        self.assertEqual(D.UPGRADE_COST["gold"], [1, 1, 1, 1, 2, 2, 2, 2, 3])

    def test_allowed_matrix(self):
        rng = random.Random(1)
        for tier in range(4):
            it = items.generate(tier, 1, rng)
            self.assertEqual(gems.can_use(it, "white"), tier in (0, 1))
            self.assertEqual(gems.can_use(it, "gold"), tier in (1, 2))
            self.assertEqual(gems.can_use(it, "purple"), tier == 3)

    def test_upgrade_flow_and_cap(self):
        rng = random.Random(1)
        for tier, gem, total in ((0, "white", 18), (2, "gold", 15), (3, "purple", 9), (1, "gold", 15)):
            it = items.generate(tier, 1, rng)
            stock = {"white": 0, "gold": 0, "purple": 0}
            stock[gem] = total - 1
            for _ in range(8):
                ok, _ = gems.upgrade(it, gem, stock)
                if it.plus < 8 and total - 1 < sum(D.UPGRADE_COST[gem][:it.plus + 1]):
                    break
            # đủ ngọc thì lên được +9, thiếu 1 viên thì dừng ở +8
            it2 = items.generate(tier, 1, rng)
            st2 = {"white": 0, "gold": 0, "purple": 0, gem: total}
            for _ in range(20):
                gems.upgrade(it2, gem, st2)
            self.assertEqual(it2.plus, 9)
            self.assertEqual(st2[gem], 0)
            ok, msg = gems.upgrade(it2, gem, {gem: 99})
            self.assertFalse(ok)
            it3 = items.generate(tier, 1, rng)
            st3 = {"white": 0, "gold": 0, "purple": 0, gem: total - 1}
            for _ in range(20):
                gems.upgrade(it3, gem, st3)
            self.assertEqual(it3.plus, 8)

    def test_wrong_gem_rejected(self):
        it = items.generate(3, 1, random.Random(1))
        stock = {"white": 50, "gold": 50, "purple": 0}
        self.assertFalse(gems.upgrade(it, "white", stock)[0])
        self.assertFalse(gems.upgrade(it, "gold", stock)[0])
        self.assertEqual(it.plus, 0)
        self.assertEqual(stock["white"], 50)

    def test_exchange(self):
        stock = {"white": 7, "gold": 0, "purple": 0}
        self.assertTrue(gems.exchange("white", stock)[0])
        self.assertTrue(gems.exchange("white", stock)[0])
        self.assertFalse(gems.exchange("white", stock)[0])      # còn 1 viên
        self.assertEqual(stock, {"white": 1, "gold": 2, "purple": 0})
        stock["gold"] = 3
        self.assertTrue(gems.exchange("gold", stock)[0])
        self.assertEqual(stock["purple"], 1)
        self.assertFalse(gems.exchange("purple", stock)[0])


class TestPlayerAndQuests(unittest.TestCase):
    def test_level_and_stats(self):
        p = Player("A")
        self.assertEqual(p.level, 1)
        hp1 = p.stats["max_hp"]
        msgs = p.gain_exp(10 ** 6)
        self.assertEqual(p.level, D.LEVEL_CAP)
        self.assertGreater(p.stats["max_hp"], hp1)
        self.assertTrue(any("LÊN CẤP" in m for m in msgs))

    def test_equip_changes_stats(self):
        p = Player("A")
        atk0 = p.stats["atk"]
        it = items.generate(3, 5, random.Random(4), slot="weapon")
        p.inventory.append(it)
        self.assertTrue(p.equip(it))
        self.assertGreater(p.stats["atk"], atk0)
        self.assertTrue(p.stats["specials"])
        old = p.equipment["weapon"]
        new = items.generate(1, 5, random.Random(5), slot="weapon")
        p.inventory.append(new)
        p.equip(new)
        self.assertIn(old, p.inventory)
        p.unequip("weapon")
        self.assertAlmostEqual(p.stats["atk"], atk0)

    def test_auto_sell_white_and_sell_all(self):
        p = Player("A")
        g0 = p.gold
        w = items.generate(0, 3, random.Random(1))
        self.assertEqual(p.receive_item(w), [])
        self.assertEqual(p.inventory, [])
        self.assertGreater(p.gold, g0)
        p.auto_sell_white = False
        p.receive_item(items.generate(0, 3, random.Random(2)))
        p.receive_item(items.generate(1, 3, random.Random(3)))
        n, total = p.sell_all_white()
        self.assertEqual(n, 1)
        self.assertEqual([i.tier for i in p.inventory], [1])

    def test_quest_flow(self):
        rng = random.Random(7)
        p = Player("A")
        q = p.quests
        self.assertEqual(q.status("m2", 1), "locked")
        self.assertEqual(q.status("m1", 1), "available")
        self.assertTrue(q.accept("m1", 1))
        self.assertEqual(q.on_event("talk", "thuong_nhan"), ["m1"])
        ok, msgs = q.turn_in("m1", p, rng)
        self.assertTrue(ok)
        self.assertEqual(p.gems["white"], 2)
        self.assertEqual(q.status("m2", 1), "available")
        q.accept("m2", 1)
        for i in range(5):
            self.assertEqual(q.on_event("kill", "soi_rung"), [])
        self.assertEqual(q.on_event("kill", "soi_rung"), ["m2"])
        ok, _ = q.turn_in("m2", p, rng)
        self.assertTrue(ok)
        self.assertEqual(sum(1 for i in p.inventory if i.tier == 1), 1)
        self.assertFalse(q.turn_in("m2", p, rng)[0])            # không trả 2 lần
        self.assertEqual(q.status("m3", 1), "locked")           # thiếu cấp
        self.assertEqual(q.status("m3", 4), "available")

    def test_save_roundtrip(self):
        rng = random.Random(11)
        p = Player("Lam")
        p.gain_exp(500)
        p.gems.update(white=5, gold=2, purple=1)
        p.pity.update(gold=12, purple=400)
        p.auto_sell_white = False
        for t in range(4):
            p.inventory.append(items.generate(t, 4, rng))
        it = items.generate(3, 4, rng, slot="ring")
        it.plus = 4
        p.inventory.append(it)
        p.equip(it)
        p.quests.accept("m1", 1)
        with tempfile.TemporaryDirectory() as td:
            path = os.path.join(td, "s.json")
            save.save_game(p, path)
            q = save.load_game(path)
        self.assertEqual(q.name, "Lam")
        self.assertEqual(q.level, p.level)
        self.assertEqual(q.gems, p.gems)
        self.assertEqual(q.pity, p.pity)
        self.assertEqual(len(q.inventory), len(p.inventory))
        self.assertEqual(q.equipment["ring"].plus, 4)
        self.assertEqual(q.equipment["ring"].special, it.special)
        self.assertAlmostEqual(q.stats["atk"], p.stats["atk"])
        self.assertEqual(q.quests.status("m1", 1), "active")
        self.assertFalse(q.auto_sell_white)
        # uid không trùng sau khi tải
        new = items.generate(0, 1, rng)
        self.assertNotIn(new.uid, [i.uid for i in q.inventory] + [i.uid for i in q.equipment.values() if i])


if __name__ == "__main__":
    unittest.main()
