# Tru Tiên – Bản Demo (chơi riêng)

Game RPG 2D cày quái, hầm mộ, giải đố, đánh boss. Python + pygame. Hình ảnh hiện là khối màu tạm.

## Chạy bằng Python
    pip install -r requirements.txt
    python main.py          (hoặc bấm run.bat)

## Điều khiển
- WASD / mũi tên: di chuyển · J hoặc Space: đánh (giữ để liên tục)
- 1–4: kỹ năng (mở ở Lv 1 / 3 / 5 / 8) · F: uống đan dược · E: nói chuyện / bật công tắc / đọc bia
- I: hành trang (mặc đồ, nâng cấp bằng ngọc, đổi ngọc, bật/tắt tự bán đồ Trắng) · Q: nhiệm vụ
- R: hồi sinh khi chết · Esc: menu tạm dừng

## Nội dung demo
Đại Trúc Phong (làng) → Rừng Trúc → U Cốc (giải 3 công tắc Đỏ→Lục→Vàng, mở cửa đá, đánh boss hoàng kim).
3 nhiệm vụ chính, 3 phụ. Cấp tối đa 20. Lưu tự động mỗi 30 giây tại `~/.tru_tien_demo/save.json`.

## Đóng gói .exe
Đẩy mã lên GitHub → tab Actions → "Build Windows exe" → tải `TruTienDemo.exe` ở mục Artifacts.
Chỉnh cân bằng (tỉ lệ rơi, ngọc, bảo hiểm, quái, nhiệm vụ) trong `trutien/data.py`.

## Kiểm thử
    python -m unittest discover -s tests -p "test_logic.py"
    python -m unittest discover -s tests -p "test_world.py"
