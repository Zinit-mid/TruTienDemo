# -*- coding: utf-8 -*-
from trutien.game import main

if __name__ == "__main__":
    main()
