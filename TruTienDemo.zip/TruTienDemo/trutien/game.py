# -*- coding: utf-8 -*-
"""Vòng lặp chính, nhập liệu, vẽ thế giới và các bảng giao diện."""
import math
import random
import time

import pygame

from . import data as D
from . import gems as G
from . import save as S
from .player import Player
from .ui import UI, W, H, pt_in
from .world import World, SHOCK_R

AUTOSAVE_SEC = 30.0
TITLE = "Tru Tiên – Bản Demo (chơi riêng)"


class Game:
    def __init__(self, screen):
        self.screen = screen
        self.ui = UI(screen)
        self.clock = pygame.time.Clock()
        self.running = True
        self.state = "menu"          # menu | name | play
        self.panel = None            # None | inv | quest | dialog | pause
        self.name_buf = ""
        self.p = None
        self.world = None
        self.sel = None              # món đồ đang chọn trong bảng hành trang
        self.scroll = 0
        self.npc = None
        self.dialog_msg = ""
        self.autosave_t = AUTOSAVE_SEC
        self.t = 0.0
        self.menu_msg = ""

    # ============================================================ vòng lặp
    def run(self):
        while self.running:
            dt = min(self.clock.tick(60) / 1000.0, 0.05)
            self.t += dt
            for ev in pygame.event.get():
                self.handle_event(ev)
            self.update(dt)
            self.draw()
            pygame.display.flip()
        if self.p and self.state == "play":
            self.save()

    # ============================================================== trạng thái
    def new_game(self, name):
        self.p = Player(name.strip() or "Vô Danh")
        self.world = World(self.p)
        self.world.say("Chào mừng %s đến Đại Trúc Phong. Hãy tìm Điền Bất Dịch (nhấn E khi đứng gần)." % self.p.name,
                       (255, 235, 170), 12.0)
        self.world.say("Di chuyển: WASD/mũi tên · Đánh: J hoặc Space · Kỹ năng: 1-4 · Đan dược: F · "
                       "Hành trang: I · Nhiệm vụ: Q", (200, 200, 210), 14.0)
        self.state, self.panel = "play", None
        self.sel = None
        self.autosave_t = AUTOSAVE_SEC
        self.save()

    def continue_game(self):
        try:
            self.p = S.load_game()
        except Exception as e:           # file hỏng
            self.menu_msg = "Không đọc được file lưu: %s" % e
            return
        self.world = World(self.p)
        self.world.say("Tiếp tục hành trình, %s." % self.p.name, (255, 235, 170), 8.0)
        self.state, self.panel = "play", None
        self.sel = None
        self.autosave_t = AUTOSAVE_SEC

    def save(self):
        try:
            S.save_game(self.p)
            return True
        except Exception as e:
            if self.world:
                self.world.say("Không lưu được: %s" % e, (255, 120, 120), 5.0)
            return False

    def to_menu(self):
        if self.p:
            self.save()
        self.state, self.panel = "menu", None
        self.menu_msg = ""

    # ================================================================ sự kiện
    def handle_event(self, ev):
        if ev.type == pygame.QUIT:
            self.running = False
        elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
            self.ui.click(ev.pos)
        elif ev.type == pygame.MOUSEWHEEL:
            if self.panel == "inv":
                self.scroll = max(0, self.scroll - ev.y)
        elif ev.type == pygame.TEXTINPUT and self.state == "name":
            if len(self.name_buf) < 16:
                self.name_buf += ev.text
        elif ev.type == pygame.KEYDOWN:
            self.on_key(ev.key)

    def on_key(self, key):
        if self.state == "menu":
            return
        if self.state == "name":
            if key == pygame.K_BACKSPACE:
                self.name_buf = self.name_buf[:-1]
            elif key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.new_game(self.name_buf)
            elif key == pygame.K_ESCAPE:
                self.state = "menu"
            return

        w, p = self.world, self.p
        if key == pygame.K_ESCAPE:
            self.panel = None if self.panel else "pause"
            return
        if self.panel == "pause":
            return
        if key == pygame.K_i:
            self.panel = None if self.panel == "inv" else "inv"
            self.scroll = 0
        elif key == pygame.K_q:
            self.panel = None if self.panel == "quest" else "quest"
        elif key == pygame.K_e:
            if self.panel == "dialog":
                self.panel = None
            elif self.panel is None:
                res = w.interact()
                if res and res[0] == "npc":
                    self.npc = res[1]
                    self.dialog_msg = ""
                    self.panel = "dialog"
        elif self.panel is None:
            if key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                w.cast(key - pygame.K_1)
            elif key == pygame.K_f:
                w.use_potion()
            elif key == pygame.K_r:
                w.respawn()

    # ================================================================ cập nhật
    def update(self, dt):
        self.ui.begin()
        if self.state != "play" or self.panel is not None:
            return
        keys = pygame.key.get_pressed()
        dx = (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT])
        dy = (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP])
        if keys[pygame.K_j] or keys[pygame.K_SPACE]:
            self.world.player_attack()
        self.world.update(dt, (dx, dy))
        self.autosave_t -= dt
        if self.autosave_t <= 0:
            self.autosave_t = AUTOSAVE_SEC
            if not self.p.dead:
                self.save()

    # ================================================================== vẽ
    def draw(self):
        # Lưu ý: ui.begin() đã chạy trong update() nên nút của khung hình này được đăng ký ở các hàm vẽ dưới.
        scr = self.screen
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "name":
            self.draw_name()
        else:
            scr.fill((12, 12, 16))
            self.draw_world()
            self.draw_hud()
            if self.panel == "inv":
                self.draw_inventory()
            elif self.panel == "quest":
                self.draw_quests()
            elif self.panel == "dialog":
                self.draw_dialog()
            elif self.panel == "pause":
                self.draw_pause()

    # ------------------------------------------------------------------ menu
    def draw_menu(self):
        ui, scr = self.ui, self.screen
        scr.fill((20, 24, 38))
        for i in range(40):
            x = (i * 137 + int(self.t * 8)) % W
            y = (i * 71) % H
            pygame.draw.circle(scr, (50, 60, 90), (x, y), 2)
        ui.text("TRU TIÊN", W // 2, 130, (255, 225, 150), ui.fxl, anchor="c")
        ui.text("Bản demo · Đại Trúc Phong – Rừng Trúc – U Cốc", W // 2, 190, (190, 200, 230), ui.fm, anchor="c")
        bx = W // 2 - 130
        ui.button((bx, 260, 260, 46), "Trò chơi mới", self.start_name)
        ui.button((bx, 318, 260, 46), "Tiếp tục", self.continue_game, enabled=S.exists())
        ui.button((bx, 376, 260, 46), "Thoát", self.quit)
        if self.menu_msg:
            ui.text(self.menu_msg, W // 2, 440, (255, 130, 120), ui.fs, anchor="c")
        ui.text("Dự án chơi riêng · dựa theo tiểu thuyết Tru Tiên của Tiêu Đỉnh · hình ảnh hiện là khối màu tạm",
                W // 2, H - 36, (130, 140, 170), ui.fs, anchor="c")

    def start_name(self):
        self.state = "name"
        self.name_buf = ""

    def quit(self):
        self.running = False

    def draw_name(self):
        ui, scr = self.ui, self.screen
        scr.fill((20, 24, 38))
        ui.text("Tạo nhân vật", W // 2, 150, (255, 225, 150), ui.fl, anchor="c")
        ui.text("Nhập tên rồi nhấn Enter (tối đa 16 ký tự, Esc để quay lại)", W // 2, 200, (190, 200, 230),
                ui.fs, anchor="c")
        box = (W // 2 - 190, 240, 380, 52)
        pygame.draw.rect(scr, (14, 16, 26), box, border_radius=6)
        pygame.draw.rect(scr, (150, 160, 210), box, 2, border_radius=6)
        caret = "|" if int(self.t * 2) % 2 == 0 else ""
        ui.text(self.name_buf + caret, W // 2, 252, (255, 255, 255), ui.fl, anchor="c")
        ui.button((W // 2 - 100, 320, 200, 44), "Bắt đầu", lambda: self.new_game(self.name_buf))

    # ----------------------------------------------------------------- thế giới
    def draw_world(self):
        w, p, scr, ui = self.world, self.p, self.screen, self.ui
        m = w.cur
        camx = p.x - W / 2
        camy = p.y - H / 2
        camx = -(W - m.w) / 2 if m.w <= W else max(0, min(m.w - W, camx))
        camy = -(H - m.h) / 2 if m.h <= H else max(0, min(m.h - H, camy))
        ox, oy = int(-camx), int(-camy)

        pygame.draw.rect(scr, m.bg, (ox, oy, m.w, m.h))
        shade = tuple(max(0, c - 10) for c in m.bg)
        for gx in range(0, m.w, 64):
            for gy in range(0, m.h, 64):
                if ((gx // 64) + (gy // 64)) % 2 == 0:
                    pygame.draw.rect(scr, shade, (ox + gx, oy + gy, 64, 64))
        pygame.draw.rect(scr, (8, 8, 10), (ox, oy, m.w, m.h), 3)

        # cổng dịch chuyển
        for pt in m.portals:
            x, y, pw, ph = pt["rect"]
            ui.fill_alpha((ox + x, oy + y, pw, ph), (120, 180, 255, 70 + int(40 * math.sin(self.t * 3))))
            pygame.draw.rect(scr, (140, 200, 255), (ox + x, oy + y, pw, ph), 2)
            lx = ox + x + pw // 2
            ly = oy + y + (ph // 2 - 8 if ph > 60 else ph + 6)
            ui.text(pt["label"], lx, ly, (190, 225, 255), ui.fs, anchor="c")

        # chướng ngại
        for o in m.obstacles:
            x, y, ow, oh = o["rect"]
            r = (ox + x, oy + y, ow, oh)
            k = o["kind"]
            if k == "tree":
                pygame.draw.rect(scr, (70, 46, 28), (r[0] + 11, r[1] + 16, 8, 16))
                pygame.draw.circle(scr, (24, 70, 36), (r[0] + 15, r[1] + 12), 17)
                pygame.draw.circle(scr, (40, 104, 54), (r[0] + 12, r[1] + 9), 11)
            elif k == "house":
                pygame.draw.rect(scr, (120, 92, 64), r)
                pygame.draw.rect(scr, (150, 60, 50), (r[0] - 6, r[1] - 10, r[2] + 12, r[3] // 3))
                pygame.draw.rect(scr, (50, 36, 26), r, 2)
            elif k == "wall":
                pygame.draw.rect(scr, (70, 66, 92), r)
                pygame.draw.rect(scr, (40, 38, 56), r, 2)
            elif k == "rock":
                pygame.draw.ellipse(scr, (100, 98, 112), r)
                pygame.draw.ellipse(scr, (60, 58, 70), r, 2)
            elif k == "door":
                pygame.draw.rect(scr, (110, 100, 130), r)
                pygame.draw.rect(scr, (230, 200, 120), r, 2)
                ui.text("Cửa đá", r[0] + r[2] // 2, r[1] + 3, (255, 240, 190), ui.fs, anchor="c")

        # bia, công tắc
        if m.sign:
            sx, sy = ox + m.sign["x"], oy + m.sign["y"]
            pygame.draw.rect(scr, (150, 150, 140), (sx - 10, sy - 18, 20, 30), border_radius=3)
            ui.text("Bia", sx, sy - 34, (220, 220, 190), ui.fs, anchor="c")
        for s in m.switches:
            c = s["color"] if s["on"] else tuple(v // 3 for v in s["color"])
            pygame.draw.circle(scr, (30, 30, 40), (ox + s["x"], oy + s["y"]), 20)
            pygame.draw.circle(scr, c, (ox + s["x"], oy + s["y"]), 15)
            ui.text(s["name"], ox + s["x"], oy + s["y"] + 22, (230, 230, 230), ui.fs, anchor="c")

        # vùng kích hoạt của vùng lửa / hiệu ứng nền
        for e in w.effects:
            if e["type"] == "zone":
                a = 70 + int(30 * math.sin(self.t * 8))
                ui.circle_alpha(ox + int(e["x"]), oy + int(e["y"]), e["r"], (255, 110, 40, a))

        # NPC
        for n in m.npcs:
            nx, ny = ox + n["x"], oy + n["y"]
            pygame.draw.circle(scr, (0, 0, 0), (nx, ny + 4), 16)
            pygame.draw.circle(scr, n["color"], (nx, ny), 15)
            pygame.draw.circle(scr, (250, 230, 200), (nx, ny - 14), 7)
            ui.text(n["name"], nx, ny - 38, (255, 235, 170), ui.fs, anchor="c")
            marker = self.quest_marker(n["id"])
            if marker:
                ui.text(marker[0], nx, ny - 58, marker[1], ui.fm, anchor="c")

        # quái
        for mo in m.monsters:
            if mo.dead:
                continue
            self.draw_monster(mo, ox, oy)

        # người chơi
        px, py = ox + int(p.x), oy + int(p.y)
        if p.dead:
            pygame.draw.circle(scr, (90, 90, 100), (px, py), 12)
            ui.text("Đã ngã xuống – nhấn R", px, py - 34, (255, 140, 140), ui.fs, anchor="c")
        else:
            if p.buff_t > 0:
                ui.circle_alpha(px, py, 26, (255, 230, 120, 90))
            pygame.draw.circle(scr, (0, 0, 0), (px, py + 3), 13)
            pygame.draw.circle(scr, (80, 140, 235), (px, py), 12)
            pygame.draw.circle(scr, (245, 220, 190), (px, py - 10), 6)
            fx, fy = px + math.cos(p.facing) * 20, py + math.sin(p.facing) * 20
            pygame.draw.line(scr, (240, 240, 255), (px, py), (fx, fy), 3)
            ui.text(p.name, px, py - 34, (200, 230, 255), ui.fs, anchor="c")

        # hiệu ứng
        for e in w.effects:
            t = e["type"]
            ex, ey = ox + int(e["x"]), oy + int(e["y"])
            if t == "slash":
                f = max(0.0, e["ttl"] / e["max"])
                a0 = e["a"] - 1.2
                pts = [(ex, ey)]
                for i in range(9):
                    a = a0 + 2.4 * i / 8
                    pts.append((ex + math.cos(a) * 66, ey + math.sin(a) * 66))
                pygame.draw.lines(scr, (255, 255, 255), False, pts[1:], max(1, int(4 * f)))
            elif t == "proj":
                pygame.draw.circle(scr, (160, 220, 255), (ex, ey), 8)
                pygame.draw.circle(scr, (255, 255, 255), (ex, ey), 4)
            elif t == "ring":
                f = 1 - e["ttl"] / e["max"]
                pygame.draw.circle(scr, e["color"], (ex, ey), max(2, int(e["r"] * (0.4 + 0.6 * f))), 3)

        # chữ nổi
        for tx in w.texts:
            ui.text(tx["s"], ox + int(tx["x"]), oy + int(tx["y"]), tx["color"], ui.fm, anchor="c")

        if w.flash_t > 0:
            ui.fill_alpha((0, 0, W, H), (200, 0, 0, int(90 * w.flash_t / 0.15)))

    def draw_monster(self, mo, ox, oy):
        scr, ui = self.screen, self.ui
        x, y = ox + int(mo.x), oy + int(mo.y)
        r = mo.radius
        if mo.shock_t > 0:
            ui.circle_alpha(x, y, SHOCK_R, (255, 60, 40, 60))
            pygame.draw.circle(scr, (255, 90, 60), (x, y), SHOCK_R, 2)
        pygame.draw.circle(scr, (0, 0, 0), (x, y + 3), r + 1)
        col = mo.d["color"]
        if mo.flash > 0:
            col = (255, 255, 255)
        pygame.draw.circle(scr, col, (x, y), r)
        pygame.draw.circle(scr, (240, 40, 40), (x - r // 3, y - r // 4), max(2, r // 6))
        pygame.draw.circle(scr, (240, 40, 40), (x + r // 3, y - r // 4), max(2, r // 6))
        if mo.kind in (D.TA, D.BOSS, D.BHK):
            ring = {D.TA: (250, 210, 70), D.BOSS: (230, 230, 240), D.BHK: (230, 50, 60)}[mo.kind]
            pygame.draw.circle(scr, ring, (x, y), r + 4, 2)
        if mo.hp < mo.max_hp or mo.aggro:
            ui.bar(x - r, y - r - 12, r * 2, 5, mo.hp / mo.max_hp, (210, 60, 60))
        ui.text("%s Lv%d" % (mo.name, mo.level), x, y - r - 30, (255, 220, 200) if mo.kind != D.QT else (220, 220, 220),
                ui.fs, anchor="c")

    def quest_marker(self, npc_id):
        """Dấu '!' / '?' trên đầu NPC."""
        ql, lv = self.p.quests, self.p.level
        qs = ql.for_giver(npc_id)
        if any(ql.status(q["id"], lv) == "ready" for q in qs):
            return ("?", (120, 230, 120))
        if any(ql.status(q["id"], lv) == "available" for q in qs):
            return ("!", (255, 225, 90))
        return None

    # ------------------------------------------------------------------- HUD
    def draw_hud(self):
        ui, p, w = self.ui, self.p, self.world
        s = p.stats
        ui.fill_alpha((8, 8, 330, 112), (10, 12, 20, 190))
        ui.text("%s · Cấp %d · %s" % (p.name, p.level, D.realm_name(p.level)), 16, 12, (255, 235, 170), ui.fm)
        ui.bar(16, 40, 300, 16, p.hp / s["max_hp"], (200, 55, 55), "%d / %d" % (p.hp, s["max_hp"]))
        ui.bar(16, 60, 300, 14, p.mp / s["max_mp"], (60, 100, 220), "%d / %d" % (p.mp, s["max_mp"]))
        need = D.exp_to_next(p.level) if p.level < D.LEVEL_CAP else 1
        frac = p.exp / need if p.level < D.LEVEL_CAP else 1.0
        ui.bar(16, 78, 300, 10, frac, (110, 190, 90))
        ui.text("Vàng %d · Đan dược %d (F)" % (p.gold, p.potions), 16, 92, (230, 210, 140), ui.fs)
        gx = 190
        for g in D.GEM_KINDS:
            ui.text("%d" % p.gems[g], gx, 92, D.GEM_COLORS[g], ui.fs)
            pygame.draw.circle(self.screen, D.GEM_COLORS[g], (gx - 8, 100), 5)
            gx += 38

        ui.text(w.cur.name + ("  (khu an toàn)" if w.cur.safe else ""), W - 16, 10, (220, 230, 255), ui.fm, anchor="r")

        # theo dõi nhiệm vụ
        y = 36
        for qid in p.quests.active_ids():
            q = D.QUEST_BY_ID[qid]
            st = p.quests.status(qid, p.level)
            n = p.quests.progress(qid)
            label = q["obj"]["label"]
            if st == "ready":
                txt, col = "%s: xong – về trả nhiệm vụ" % q["name"], (130, 240, 130)
            else:
                txt, col = "%s: %s %d/%d" % (q["name"], label, n, q["obj"]["count"]), (230, 230, 240)
            ui.text(txt, W - 16, y, col, ui.fs, anchor="r")
            y += 20

        # thanh boss
        for mo in w.cur.monsters:
            if not mo.dead and mo.kind in (D.BOSS, D.BHK) and mo.aggro:
                ui.bar(W // 2 - 220, 14, 440, 18, mo.hp / mo.max_hp, (190, 50, 60),
                       "%s  %d/%d" % (mo.name, mo.hp, mo.max_hp))
                break

        # thanh kỹ năng
        for i, sk in enumerate(D.SKILLS):
            x = W // 2 - 170 + i * 88
            y0 = H - 66
            unlocked = p.level >= sk["unlock"]
            pygame.draw.rect(self.screen, (22, 24, 34), (x, y0, 80, 52), border_radius=5)
            if unlocked and p.skill_cd[i] > 0 and sk["cd"] > 0:
                f = min(1.0, p.skill_cd[i] / sk["cd"])
                ui.fill_alpha((x, y0, 80, int(52 * f)), (0, 0, 0, 170))
            pygame.draw.rect(self.screen, (150, 160, 200) if unlocked else (70, 70, 80), (x, y0, 80, 52), 1,
                             border_radius=5)
            ui.text("[%s]" % sk["key"], x + 5, y0 + 3, (255, 235, 170), ui.fs)
            nm = sk["name"] if unlocked else "Mở Lv%d" % sk["unlock"]
            lines = ui.wrap(nm, 74)
            for j, ln in enumerate(lines[:2]):
                ui.text(ln, x + 40, y0 + 18 + j * 15, (235, 235, 245) if unlocked else (130, 130, 140), ui.fs, anchor="c")
            if unlocked and p.skill_cd[i] > 0:
                ui.text("%.1f" % p.skill_cd[i], x + 74, y0 + 3, (255, 200, 120), ui.fs, anchor="r")

        # gợi ý tương tác
        if self.panel is None and not p.dead:
            hint = None
            n = w.nearby_npc()
            if n:
                hint = "E: Nói chuyện với %s" % n["name"]
            elif w.nearby_switch() is not None:
                hint = "E: Bật công tắc"
            elif w.near_sign():
                hint = "E: Đọc bia"
            if hint:
                ui.text(hint, W // 2, H - 100, (255, 245, 190), ui.fm, anchor="c")

        # thông báo
        y = H - 80
        for txt, col, ttl in reversed(w.messages[-6:]):
            alpha_col = col if ttl > 1.0 else tuple(int(c * ttl) for c in col)
            for ln in reversed(ui.wrap(txt, 420)):
                ui.text(ln, 16, y, alpha_col, ui.fs)
                y -= 18
            if y < H // 2:
                break

        ui.text("I Hành trang · Q Nhiệm vụ · Esc Menu", W - 16, H - 24, (150, 160, 190), ui.fs, anchor="r")

    # ------------------------------------------------------------ hành trang
    def draw_inventory(self):
        ui, p = self.ui, self.p
        rect = (30, 30, W - 60, H - 60)
        ui.panel(rect, "Hành trang & Trang bị   (cuộn chuột để xem thêm)")
        ui.button((W - 90, 38, 50, 26), "X", self.close_panel, color=(110, 50, 50))

        # --- trang bị đang mặc
        ui.text("Đang mặc", 50, 76, (180, 190, 230), ui.fm)
        for i, slot in enumerate(D.SLOTS):
            y = 104 + i * 52
            it = p.equipment[slot]
            r = (50, y, 290, 46)
            pygame.draw.rect(self.screen, (30, 34, 48), r, border_radius=4)
            border = D.TIER_COLORS[it.tier] if it else (80, 80, 95)
            if it is not None and it is self.sel:
                border = (255, 255, 255)
            pygame.draw.rect(self.screen, border, r, 2, border_radius=4)
            ui.text(D.SLOT_NAMES[slot], 58, y + 4, (150, 160, 190), ui.fs)
            if it:
                ui.text(it.display_name(), 58, y + 23, D.TIER_COLORS[it.tier], ui.fs)
                ui.hotspot(r, (lambda i=it: self.select(i)))
            else:
                ui.text("(trống)", 58, y + 23, (110, 110, 125), ui.fs)

        # --- danh sách hành trang
        inv = sorted(p.inventory, key=lambda i: (-i.tier, -i.plus, -i.ilvl, i.slot))
        per = 11
        self.scroll = max(0, min(self.scroll, max(0, len(inv) - per)))
        ui.text("Hành trang %d/%d" % (len(inv), D.INVENTORY_CAP), 360, 76, (180, 190, 230), ui.fm)
        for row, it in enumerate(inv[self.scroll:self.scroll + per]):
            y = 104 + row * 36
            r = (360, y, 300, 32)
            pygame.draw.rect(self.screen, (30, 34, 48), r, border_radius=4)
            border = (255, 255, 255) if it is self.sel else D.TIER_COLORS[it.tier]
            pygame.draw.rect(self.screen, border, r, 2, border_radius=4)
            ui.text(it.display_name(), 368, y + 7, D.TIER_COLORS[it.tier], ui.fs)
            ui.text(D.SLOT_NAMES[it.slot], 650, y + 7, (150, 160, 190), ui.fs, anchor="r")
            ui.hotspot(r, (lambda i=it: self.select(i)))
        if not inv:
            ui.text("(trống)", 370, 112, (110, 110, 125), ui.fs)

        # --- chi tiết món đồ
        x0 = 690
        sel = self.sel
        if sel is not None and sel not in p.inventory and sel not in p.equipment.values():
            sel = self.sel = None
        if sel is not None:
            y = 76
            for txt, col in sel.lines():
                for ln in ui.wrap(txt, 300):
                    ui.text(ln, x0, y, col or (170, 180, 210), ui.fs)
                    y += 19
            y += 6
            equipped = sel in p.equipment.values()
            if not equipped:
                ui.button((x0, y, 140, 30), "Mặc", self.do_equip)
            else:
                ui.button((x0, y, 140, 30), "Cởi xuống", self.do_unequip)
            y += 38
            ui.text("Nâng cấp bằng ngọc:", x0, y, (180, 190, 230), ui.fs)
            y += 22
            for g in D.GEM_KINDS:
                ok = G.can_use(sel, g)
                cost = G.next_cost(sel, g)
                if not ok:
                    continue
                label = "%s (đã tối đa)" % D.GEM_NAMES[g] if cost is None else \
                    "%s  cần %d (có %d)" % (D.GEM_NAMES[g], cost, p.gems[g])
                enable = cost is not None and p.gems[g] >= cost
                ui.button((x0, y, 290, 28), label, (lambda g=g: self.do_upgrade(g)), enabled=enable)
                y += 34

        # --- ngọc & đổi ngọc (dưới cùng bên trái)
        ui.text("Ngọc: Trắng %d · Vàng %d · Tím %d" % (p.gems["white"], p.gems["gold"], p.gems["purple"]),
                360, 512, (230, 230, 240), ui.fs)
        ui.button((360, 536, 150, 28), "3 Trắng → 1 Vàng", lambda: self.do_exchange("white"),
                  enabled=p.gems["white"] >= 3)
        ui.button((520, 536, 150, 28), "3 Vàng → 1 Tím", lambda: self.do_exchange("gold"),
                  enabled=p.gems["gold"] >= 3)
        ui.button((50, 536, 290, 28), "Tự bán đồ Trắng: %s" % ("BẬT" if p.auto_sell_white else "TẮT"),
                  self.toggle_auto_sell)
        ui.text("Bảo hiểm: Vàng %d/%d · Tím %d/%d" % (p.pity["gold"], D.PITY[2], p.pity["purple"], D.PITY[3]),
                50, 512, (170, 180, 210), ui.fs)
        self.draw_stat_summary()

    def draw_stat_summary(self):
        ui, s = self.ui, self.p.stats
        x, y = 690, 400
        rows = [("Công", s["atk"]), ("Thủ", s["def"]), ("Tốc đánh", 0.5 / s["atk_interval"]),
                ("Bạo kích %", s["crit"]), ("Né %", s["dodge"]), ("May mắn %", s["luck"])]
        txt = " · ".join("%s %s" % (k, ("%.1f" % v) if isinstance(v, float) and v < 100 else int(v))
                         for k, v in rows)
        for i, ln in enumerate(ui.wrap(txt, 300)):
            ui.text(ln, x, y + i * 18, (170, 200, 170), ui.fs)
        ui.text("Hiệu ứng Tím: " + (", ".join(D.SPECIALS[k][0] for k in s["specials"]) or "không"),
                x, y + 64, (190, 140, 240), ui.fs)

    def select(self, item):
        self.sel = item

    def close_panel(self):
        self.panel = None

    def do_equip(self):
        if self.sel and self.p.equip(self.sel):
            self.world.say("Đã mặc %s." % self.sel.display_name(), (200, 230, 200), 3.0)

    def do_unequip(self):
        it = self.sel
        if it and it.slot in self.p.equipment and self.p.equipment[it.slot] is it:
            if not self.p.unequip(it.slot):
                self.world.say("Hành trang đầy.", (255, 140, 120), 3.0)

    def do_upgrade(self, gem):
        if not self.sel:
            return
        ok, msg = G.upgrade(self.sel, gem, self.p.gems)
        self.world.say(msg, (140, 255, 170) if ok else (255, 150, 130), 4.0)
        if ok:
            self.p.recalc()

    def do_exchange(self, src):
        ok, msg = G.exchange(src, self.p.gems)
        self.world.say(msg, (140, 255, 170) if ok else (255, 150, 130), 4.0)

    def toggle_auto_sell(self):
        self.p.auto_sell_white = not self.p.auto_sell_white

    # -------------------------------------------------------------- nhiệm vụ
    def draw_quests(self):
        ui, p = self.ui, self.p
        rect = (60, 50, W - 120, H - 100)
        ui.panel(rect, "Nhật ký nhiệm vụ")
        ui.button((W - 120, 58, 50, 26), "X", self.close_panel, color=(110, 50, 50))
        y = 96
        for q in D.QUESTS:
            st = p.quests.status(q["id"], p.level)
            if st == "locked":
                continue
            tag = "[Chính]" if q["main"] else "[Phụ]"
            col = {"done": (130, 140, 130), "ready": (130, 240, 130), "active": (255, 235, 170),
                   "available": (200, 220, 255)}[st]
            stt = {"done": "đã xong", "ready": "chờ trả", "active": "%d/%d" % (p.quests.progress(q["id"]),
                                                                              q["obj"]["count"]),
                   "available": "chưa nhận – gặp %s" % self.npc_name(q["giver"])}[st]
            ui.text("%s %s  –  %s" % (tag, q["name"], stt), 80, y, col, ui.fm)
            y += 24
            for ln in ui.wrap(q["desc"], W - 200):
                ui.text(ln, 100, y, (170, 175, 200), ui.fs)
                y += 18
            ui.text("Thưởng: " + self.reward_text(q["reward"]), 100, y, (200, 180, 120), ui.fs)
            y += 30

    @staticmethod
    def npc_name(npc_id):
        for c in D.MAPS.values():
            for n in c["npcs"]:
                if n["id"] == npc_id:
                    return n["name"]
        return npc_id

    @staticmethod
    def reward_text(r):
        parts = []
        if r.get("exp"):
            parts.append("%d EXP" % r["exp"])
        if r.get("gold"):
            parts.append("%d vàng" % r["gold"])
        for g, (lo, hi) in r.get("gems", {}).items():
            parts.append("%s %s" % ((str(lo) if lo == hi else "%d-%d" % (lo, hi)), D.GEM_NAMES[g]))
        for g, (ch, n) in r.get("gem_chance", {}).items():
            parts.append("%d%% có %d %s" % (round(ch * 100), n, D.GEM_NAMES[g]))
        for tier, n in r.get("items", []):
            parts.append("%d đồ %s" % (n, D.TIER_NAMES[tier]))
        return ", ".join(parts)

    # ------------------------------------------------------------- hội thoại
    def draw_dialog(self):
        ui, p, n = self.ui, self.p, self.npc
        rect = (110, 70, W - 220, H - 140)
        ui.panel(rect, n["name"])
        ui.button((W - 180, 78, 50, 26), "X", self.close_panel, color=(110, 50, 50))
        y = 104
        for ln in ui.wrap(D.NPC_TEXT.get(n["id"], "..."), W - 280, ui.fm):
            ui.text(ln, 136, y, (235, 235, 245), ui.fm)
            y += 24
        y += 10
        ql = p.quests
        for q in ql.for_giver(n["id"]):
            st = ql.status(q["id"], p.level)
            if st in ("locked", "done"):
                continue
            tag = "[Chính]" if q["main"] else "[Phụ]"
            ui.text("%s %s" % (tag, q["name"]), 136, y, (255, 235, 170), ui.fm)
            y += 24
            for ln in ui.wrap(q["desc"], W - 360):
                ui.text(ln, 150, y, (180, 185, 210), ui.fs)
                y += 18
            ui.text("Thưởng: " + self.reward_text(q["reward"]), 150, y, (200, 180, 120), ui.fs)
            by = y - 2
            if st == "available":
                ui.button((W - 330, by - 14, 170, 30), "Nhận nhiệm vụ", (lambda qid=q["id"]: self.accept_quest(qid)))
            elif st == "ready":
                ui.button((W - 330, by - 14, 170, 30), "Trả nhiệm vụ", (lambda qid=q["id"]: self.turn_in(qid)),
                          color=(50, 110, 60))
            else:
                ui.text("Đang làm %d/%d" % (ql.progress(q["id"]), q["obj"]["count"]), W - 245, by - 6,
                        (200, 200, 210), ui.fs, anchor="c")
            y += 38
        if n["id"] == "thuong_nhan":
            by = H - 200
            ui.text("Cửa hàng", 136, by - 26, (255, 235, 170), ui.fm)
            ui.button((136, by, 230, 32), "Mua đan dược (%d vàng)" % D.POTION_PRICE, self.buy_potion)
            nw = sum(1 for i in p.inventory if i.tier == 0)
            nx = sum(1 for i in p.inventory if i.tier == 1)
            ui.button((376, by, 230, 32), "Bán hết đồ Trắng (%d)" % nw, lambda: self.sell_tier(0), enabled=nw > 0)
            ui.button((616, by, 230, 32), "Bán hết đồ Xanh (%d)" % nx, lambda: self.sell_tier(1), enabled=nx > 0)
        if self.dialog_msg:
            ui.text(self.dialog_msg, W // 2, H - 110, (180, 255, 190), ui.fs, anchor="c")

    def accept_quest(self, qid):
        if self.p.quests.accept(qid, self.p.level):
            self.world.notify_quest_accepted(qid)
            self.dialog_msg = "Đã nhận nhiệm vụ: %s" % D.QUEST_BY_ID[qid]["name"]
            self.save()

    def turn_in(self, qid):
        ok, msgs = self.p.quests.turn_in(qid, self.p, self.world.rng)
        if ok:
            self.dialog_msg = "Hoàn thành: %s" % D.QUEST_BY_ID[qid]["name"]
            for m in msgs:
                self.world.say(m, (140, 255, 170), 8.0)
            self.save()

    def buy_potion(self):
        ok, msg = self.p.buy_potion()
        self.dialog_msg = msg

    def sell_tier(self, tier):
        n, total = self.p.sell_all_tier(tier)
        self.dialog_msg = "Đã bán %d món đồ %s, nhận %d vàng." % (n, D.TIER_NAMES[tier], total)

    # ----------------------------------------------------------------- tạm dừng
    def draw_pause(self):
        ui = self.ui
        ui.fill_alpha((0, 0, W, H), (0, 0, 0, 150))
        ui.text("Tạm dừng", W // 2, 170, (255, 225, 150), ui.fl, anchor="c")
        bx = W // 2 - 120
        ui.button((bx, 230, 240, 44), "Tiếp tục", self.close_panel)
        ui.button((bx, 286, 240, 44), "Lưu game", self.save_click)
        ui.button((bx, 342, 240, 44), "Về menu chính", self.to_menu)
        ui.button((bx, 398, 240, 44), "Thoát game", self.quit_save)
        if self.dialog_msg:
            ui.text(self.dialog_msg, W // 2, 470, (180, 255, 190), ui.fs, anchor="c")

    def save_click(self):
        self.dialog_msg = "Đã lưu." if self.save() else "Lưu thất bại."

    def quit_save(self):
        self.save()
        self.running = False


def main():
    pygame.init()
    pygame.display.set_caption(TITLE)
    screen = pygame.display.set_mode((W, H))
    Game(screen).run()
    pygame.quit()
