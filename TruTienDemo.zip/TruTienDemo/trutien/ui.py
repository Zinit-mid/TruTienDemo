# -*- coding: utf-8 -*-
"""Tiện ích vẽ giao diện bằng pygame (kiểu 'immediate mode': nút được đăng ký lại mỗi khung hình)."""
import pygame

W, H = 1024, 640


def pt_in(rect, pos):
    x, y, w, h = rect
    return x <= pos[0] <= x + w and y <= pos[1] <= y + h


class UI:
    def __init__(self, screen):
        self.screen = screen
        names = "segoeui,tahoma,arial,dejavusans,freesans"
        self.fs = pygame.font.SysFont(names, 15)
        self.fm = pygame.font.SysFont(names, 18)
        self.fl = pygame.font.SysFont(names, 26, bold=True)
        self.fxl = pygame.font.SysFont(names, 44, bold=True)
        self.buttons = []         # (rect, callback, enabled)
        self.mouse = (0, 0)
        self._cache = {}

    # ------------------------------------------------------------- khung hình
    def begin(self):
        self.buttons = []
        self.mouse = pygame.mouse.get_pos()
        if len(self._cache) > 800:
            self._cache.clear()

    def click(self, pos):
        for rect, cb, enabled in reversed(self.buttons):
            if pt_in(rect, pos):
                if enabled and cb:
                    cb()
                return True
        return False

    # ----------------------------------------------------------------- chữ
    def _render(self, font, s, color):
        key = (id(font), s, color)
        img = self._cache.get(key)
        if img is None:
            img = font.render(s, True, color)
            self._cache[key] = img
        return img

    def text(self, s, x, y, color=(235, 235, 235), font=None, shadow=True, anchor="l"):
        f = font or self.fs
        img = self._render(f, s, color)
        w = img.get_width()
        if anchor == "c":
            x -= w // 2
        elif anchor == "r":
            x -= w
        if shadow:
            self.screen.blit(self._render(f, s, (0, 0, 0)), (x + 1, y + 1))
        self.screen.blit(img, (x, y))
        return w

    def wrap(self, s, width, font=None):
        f = font or self.fs
        lines, cur = [], ""
        for word in s.split(" "):
            trial = (cur + " " + word).strip()
            if cur and self._render(f, trial, (0, 0, 0)).get_width() > width:
                lines.append(cur)
                cur = word
            else:
                cur = trial
        if cur:
            lines.append(cur)
        return lines

    # -------------------------------------------------------------- hình khối
    def fill_alpha(self, rect, rgba):
        x, y, w, h = rect
        surf = pygame.Surface((max(1, int(w)), max(1, int(h))), pygame.SRCALPHA)
        surf.fill(rgba)
        self.screen.blit(surf, (x, y))

    def circle_alpha(self, cx, cy, r, rgba):
        r = max(1, int(r))
        surf = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
        pygame.draw.circle(surf, rgba, (r, r), r)
        self.screen.blit(surf, (cx - r, cy - r))

    def bar(self, x, y, w, h, frac, color, label=None):
        frac = max(0.0, min(1.0, frac))
        pygame.draw.rect(self.screen, (25, 25, 32), (x, y, w, h))
        if frac > 0:
            pygame.draw.rect(self.screen, color, (x, y, int(w * frac), h))
        pygame.draw.rect(self.screen, (10, 10, 14), (x, y, w, h), 1)
        if label:
            self.text(label, x + w // 2, y + max(0, (h - 15) // 2 - 1), (255, 255, 255), self.fs, anchor="c")

    def panel(self, rect, title=None):
        self.fill_alpha(rect, (18, 20, 30, 238))
        pygame.draw.rect(self.screen, (120, 130, 170), rect, 2)
        if title:
            self.text(title, rect[0] + 16, rect[1] + 10, (255, 235, 170), self.fm)

    # ------------------------------------------------------------------ nút
    def hotspot(self, rect, cb, enabled=True):
        self.buttons.append((rect, cb, enabled))

    def button(self, rect, label, cb, enabled=True, color=(58, 70, 112)):
        hover = enabled and pt_in(rect, self.mouse)
        c = color if enabled else (45, 45, 52)
        if hover:
            c = tuple(min(255, v + 28) for v in c)
        pygame.draw.rect(self.screen, c, rect, border_radius=5)
        pygame.draw.rect(self.screen, (150, 160, 200) if enabled else (80, 80, 90), rect, 1, border_radius=5)
        tc = (240, 240, 250) if enabled else (130, 130, 140)
        x, y, w, h = rect
        self.text(label, x + w // 2, y + max(0, (h - 16) // 2 - 1), tc, self.fs, shadow=enabled, anchor="c")
        self.hotspot(rect, cb, enabled)
