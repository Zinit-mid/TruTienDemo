# -*- coding: utf-8 -*-
"""Nhân vật người chơi: chỉ số, cấp độ, hành trang, trang bị, ngọc."""
from . import data as D
from . import items as I
from .quests import QuestLog


class Player:
    def __init__(self, name):
        self.name = name
        self.level = 1
        self.exp = 0
        self.gold = 60
        self.potions = 3
        self.inventory = []
        self.equipment = {s: None for s in D.SLOTS}
        self.gems = {"white": 0, "gold": 0, "purple": 0}
        self.pity = {"gold": 0, "purple": 0}
        self.auto_sell_white = True
        self.kills = 0
        self.quests = QuestLog()
        self.map = D.HUB_MAP
        self.x, self.y = D.MAPS[D.HUB_MAP]["start"]
        # --- trạng thái chạy (không lưu) ---
        self.facing = 0.0            # góc (radian), 0 = sang phải
        self.stats = {}
        self.hp = self.mp = 1.0
        self.atk_cd = 0.0
        self.skill_cd = [0.0] * len(D.SKILLS)
        self.potion_cd = 0.0
        self.buff_t = 0.0            # thời gian còn lại của Bát Nhã Hộ Thể
        self.dead = False
        self.recalc()
        self.hp, self.mp = self.stats["max_hp"], self.stats["max_mp"]

    # ------------------------------------------------------------- chỉ số
    def recalc(self):
        """Tính lại toàn bộ chỉ số từ cấp độ và trang bị."""
        b = D.base_stats_for_level(self.level)
        tot = {}
        for it in self.equipment.values():
            if it:
                for k, v in it.stats().items():
                    tot[k] = tot.get(k, 0.0) + v
        g = lambda k: tot.get(k, 0.0)

        s = {}
        s["max_hp"] = (b["hp"] + g("hp")) * (1 + g("hp_pct") / 100)
        s["max_mp"] = (b["mp"] + g("mp")) * (1 + g("mp_pct") / 100)
        s["atk"] = (b["atk"] + g("atk")) * (1 + g("atk_pct") / 100)
        s["def"] = (b["def"] + g("def")) * (1 + g("def_pct") / 100)
        s["move"] = 165 * (1 + g("move_speed") / 100)
        s["atk_interval"] = 0.5 / (1 + g("atk_speed") / 100)
        s["crit"] = 5 + g("crit")
        s["crit_dmg"] = 150 + g("crit_dmg")
        s["dodge"] = g("dodge")
        s["hp_regen"] = 1.0 + g("hp_regen")
        s["mp_regen"] = 2.0 + g("mp_regen")
        s["lifesteal"] = g("lifesteal")
        s["exp_bonus"] = g("exp_bonus")
        s["luck"] = min(g("luck"), D.LUCK_CAP)
        s["resist"] = min(g("resist"), D.RESIST_CAP)
        s["cdr"] = min(g("cdr"), D.CDR_CAP)

        # hiệu ứng đặc biệt của đồ Tím
        sp = {}
        for it in self.equipment.values():
            if it and it.special:
                sp[it.special] = sp.get(it.special, 0.0) + it.special_value()
        s["specials"] = sp

        old_hp = getattr(self, "hp", s["max_hp"])
        old_mp = getattr(self, "mp", s["max_mp"])
        self.stats = s
        self.hp = min(old_hp, s["max_hp"])
        self.mp = min(old_mp, s["max_mp"])

    # --------------------------------------------------------------- EXP
    def gain_exp(self, amount, from_quest=False):
        msgs = []
        if self.level >= D.LEVEL_CAP:
            return msgs
        if not from_quest:
            amount = int(amount * (1 + self.stats["exp_bonus"] / 100))
        self.exp += amount
        msgs.append("+%d EXP" % amount)
        while self.level < D.LEVEL_CAP and self.exp >= D.exp_to_next(self.level):
            self.exp -= D.exp_to_next(self.level)
            self.level += 1
            self.recalc()
            self.hp, self.mp = self.stats["max_hp"], self.stats["max_mp"]
            msgs.append("LÊN CẤP! Cấp %d (%s)" % (self.level, D.realm_name(self.level)))
            for sk in D.SKILLS:
                if sk["unlock"] == self.level:
                    msgs.append("Học được kỹ năng: %s" % sk["name"])
        if self.level >= D.LEVEL_CAP:
            self.exp = 0
        return msgs

    # ------------------------------------------------------- hành trang
    def receive_item(self, item):
        """Nhận một món đồ. Đồ Trắng tự bán nếu bật. Trả về danh sách thông báo."""
        if item.tier == 0 and self.auto_sell_white:
            self.gold += item.sell_price()
            return []
        if len(self.inventory) >= D.INVENTORY_CAP:
            self.gold += item.sell_price()
            return ["Hành trang đầy, tự bán %s (+%d vàng)." % (item.display_name(), item.sell_price())]
        self.inventory.append(item)
        return []

    def find_item(self, uid):
        for it in self.inventory:
            if it.uid == uid:
                return it
        return None

    def equip(self, item):
        """Mặc đồ từ hành trang; đồ cũ quay về hành trang."""
        if item not in self.inventory:
            return False
        old = self.equipment[item.slot]
        self.inventory.remove(item)
        self.equipment[item.slot] = item
        if old:
            self.inventory.append(old)
        self.recalc()
        return True

    def unequip(self, slot):
        it = self.equipment.get(slot)
        if not it or len(self.inventory) >= D.INVENTORY_CAP:
            return False
        self.equipment[slot] = None
        self.inventory.append(it)
        self.recalc()
        return True

    def sell(self, item):
        if item not in self.inventory:
            return 0
        self.inventory.remove(item)
        price = item.sell_price()
        self.gold += price
        return price

    def sell_all_tier(self, tier):
        """Bán toàn bộ đồ trong hành trang thuộc cấp `tier` (không đụng tới đồ đang mặc)."""
        picked = [i for i in self.inventory if i.tier == tier]
        total = sum(i.sell_price() for i in picked)
        self.inventory = [i for i in self.inventory if i.tier != tier]
        self.gold += total
        return len(picked), total

    def sell_all_white(self):
        return self.sell_all_tier(0)

    def buy_potion(self):
        if self.potions >= D.POTION_MAX:
            return False, "Đã mang tối đa %d đan dược." % D.POTION_MAX
        if self.gold < D.POTION_PRICE:
            return False, "Không đủ vàng."
        self.gold -= D.POTION_PRICE
        self.potions += 1
        return True, "Mua 1 đan dược (-%d vàng)." % D.POTION_PRICE

    # ------------------------------------------------------------ lưu/tải
    def to_dict(self):
        return {
            "name": self.name, "level": self.level, "exp": self.exp, "gold": self.gold,
            "potions": self.potions, "gems": self.gems, "pity": self.pity,
            "auto_sell_white": self.auto_sell_white, "kills": self.kills,
            "map": self.map, "x": self.x, "y": self.y,
            "inventory": [i.to_dict() for i in self.inventory],
            "equipment": {s: (i.to_dict() if i else None) for s, i in self.equipment.items()},
            "quests": self.quests.to_dict(),
            "hp": self.hp, "mp": self.mp,
        }

    @staticmethod
    def from_dict(d):
        p = Player(d["name"])
        p.level = d.get("level", 1)
        p.exp = d.get("exp", 0)
        p.gold = d.get("gold", 0)
        p.potions = d.get("potions", 0)
        p.gems = {k: d.get("gems", {}).get(k, 0) for k in D.GEM_KINDS}
        p.pity = {"gold": d.get("pity", {}).get("gold", 0), "purple": d.get("pity", {}).get("purple", 0)}
        p.auto_sell_white = d.get("auto_sell_white", True)
        p.kills = d.get("kills", 0)
        p.map = d.get("map", D.HUB_MAP) if d.get("map") in D.MAPS else D.HUB_MAP
        p.x, p.y = d.get("x", 600), d.get("y", 400)
        p.inventory = [I.Item.from_dict(x) for x in d.get("inventory", [])]
        p.equipment = {s: None for s in D.SLOTS}
        for s, x in d.get("equipment", {}).items():
            if s in p.equipment and x:
                p.equipment[s] = I.Item.from_dict(x)
        p.quests = QuestLog.from_dict(d.get("quests", {}))
        p.hp = 1.0
        p.recalc()
        p.hp = min(d.get("hp", p.stats["max_hp"]), p.stats["max_hp"])
        p.mp = min(d.get("mp", p.stats["max_mp"]), p.stats["max_mp"])
        if p.hp <= 0:
            p.hp = p.stats["max_hp"]
        return p
