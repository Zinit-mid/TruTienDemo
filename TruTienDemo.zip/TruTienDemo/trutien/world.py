# -*- coding: utf-8 -*-
"""Thế giới, quái vật và chiến đấu. Không phụ thuộc pygame nên chạy giả lập được."""
import math
import random

from . import data as D
from . import loot

PLAYER_R = 12
MELEE_RANGE = 62
MELEE_ARC = math.radians(80)       # nửa góc của cung chém
LEASH = 650
SHOCK_R = 130


def _rect_hit(cx, cy, r, rect):
    x, y, w, h = rect
    nx = min(max(cx, x), x + w)
    ny = min(max(cy, y), y + h)
    return (cx - nx) ** 2 + (cy - ny) ** 2 < r * r


def _in_rect(px, py, rect):
    x, y, w, h = rect
    return x <= px <= x + w and y <= py <= y + h


def _angle_diff(a, b):
    d = (a - b + math.pi) % (2 * math.pi) - math.pi
    return abs(d)


class Monster:
    def __init__(self, mid, x, y):
        d = D.MONSTERS[mid]
        self.mid = mid
        self.d = d
        self.name = d["name"]
        self.level = d["level"]
        self.kind = d["kind"]
        self.max_hp = float(d["hp"])
        self.hp = self.max_hp
        self.atk = d["atk"]
        self.defn = d["def"]
        self.speed = d["speed"]
        self.radius = d["radius"]
        self.x, self.y = x, y
        self.home = (x, y)
        self.cd = 0.0
        self.dead = False
        self.respawn_t = 0.0
        self.aggro = False
        self.burn_t = 0.0
        self.burn_dps = 0.0
        self.burn_acc = 0.0
        self.wander = (x, y)
        self.wander_t = 0.0
        self.flash = 0.0
        self.shock_cd = 5.0
        self.shock_t = 0.0

    def revive(self):
        self.hp = self.max_hp
        self.x, self.y = self.home
        self.dead = False
        self.aggro = False
        self.burn_t = 0.0
        self.shock_t = 0.0
        self.shock_cd = 5.0
        self.cd = 1.0


class MapState:
    def __init__(self, key, rng):
        cfg = D.MAPS[key]
        self.key = key
        self.cfg = cfg
        self.name = cfg["name"]
        self.w, self.h = cfg["w"], cfg["h"]
        self.bg = cfg["bg"]
        self.safe = cfg["safe"]
        self.obstacles = [{"rect": (x, y, w, h), "kind": k} for (x, y, w, h, k) in cfg["obstacles"]]
        self.door = None
        if cfg.get("door"):
            self.door = {"rect": tuple(cfg["door"]), "kind": "door"}
            self.obstacles.append(self.door)
        self.portals = cfg["portals"]
        self.npcs = cfg["npcs"]
        self.switches = [dict(s, on=False) for s in cfg.get("switches", [])]
        self.switch_order = cfg.get("switch_order", [])
        self.switch_progress = []
        self.solved = False
        self.sign = cfg.get("sign")
        self.visited = False
        self.monsters = []
        self._place_trees()
        self._spawn(rng)

    # ---------------------------------------------------------------- tạo
    def _arrival_points(self):
        pts = []
        for k, c in D.MAPS.items():
            for p in c["portals"]:
                if p["to"] == self.key:
                    pts.append(p["spawn"])
        if "start" in self.cfg:
            pts.append(self.cfg["start"])
        return pts

    def _free(self, x, y, r):
        if x < r or y < r or x > self.w - r or y > self.h - r:
            return False
        for o in self.obstacles:
            if _rect_hit(x, y, r, o["rect"]):
                return False
        for p in self.portals:
            px, py, pw, ph = p["rect"]
            if _rect_hit(x, y, r + 70, (px, py, pw, ph)):
                return False
        for n in self.npcs:
            if (x - n["x"]) ** 2 + (y - n["y"]) ** 2 < (r + 80) ** 2:
                return False
        for s in self.switches:
            if (x - s["x"]) ** 2 + (y - s["y"]) ** 2 < (r + 60) ** 2:
                return False
        return True

    def _place_trees(self):
        n = self.cfg.get("trees", 0)
        if not n:
            return
        rng = random.Random(self.cfg.get("tree_seed", 1))
        arrivals = self._arrival_points()
        tries = 0
        placed = 0
        while placed < n and tries < n * 40:
            tries += 1
            x = rng.uniform(40, self.w - 70)
            y = rng.uniform(40, self.h - 70)
            if any((x - ax) ** 2 + (y - ay) ** 2 < 150 ** 2 for ax, ay in arrivals):
                continue
            if not self._free(x + 15, y + 15, 24):
                continue
            self.obstacles.append({"rect": (x, y, 30, 30), "kind": "tree"})
            placed += 1

    def _spawn(self, rng):
        if self.safe:
            return
        arrivals = self._arrival_points()
        fixed = self.cfg.get("fixed_spawns", {})
        regions = self.cfg.get("regions", {})
        for mid, count in self.cfg.get("spawns", []):
            for _ in range(count):
                if mid in fixed:
                    x, y = fixed[mid]
                else:
                    x0, y0, x1, y1 = regions.get(mid, (220, 100, self.w - 120, self.h - 100))
                    for _try in range(200):
                        x, y = rng.uniform(x0, x1), rng.uniform(y0, y1)
                        if not self._free(x, y, 34):
                            continue
                        if any((x - ax) ** 2 + (y - ay) ** 2 < 280 ** 2 for ax, ay in arrivals):
                            continue
                        break
                self.monsters.append(Monster(mid, x, y))


class World:
    def __init__(self, player, rng=None):
        self.p = player
        self.rng = rng or random.Random()
        self.maps = {k: MapState(k, self.rng) for k in D.MAPS}
        self.cur = self.maps[player.map]
        self.cur.visited = True
        self.effects = []
        self.texts = []
        self.messages = []        # [chữ, màu, thời gian còn lại]
        self.flash_t = 0.0

    # ---------------------------------------------------------------- tiện ích
    def say(self, text, color=(235, 235, 235), ttl=7.0):
        self.messages.append([text, color, ttl])
        if len(self.messages) > 12:
            self.messages.pop(0)

    def _text(self, x, y, s, color, ttl=0.9):
        self.texts.append({"x": x, "y": y, "s": s, "color": color, "ttl": ttl})

    def _blocked(self, x, y, r):
        if x < r or y < r or x > self.cur.w - r or y > self.cur.h - r:
            return True
        for o in self.cur.obstacles:
            if _rect_hit(x, y, r, o["rect"]):
                return True
        return False

    def _move(self, ent, dx, dy, r):
        nx = ent.x + dx
        if not self._blocked(nx, ent.y, r):
            ent.x = nx
        ny = ent.y + dy
        if not self._blocked(ent.x, ny, r):
            ent.y = ny

    def alive_monsters(self):
        return [m for m in self.cur.monsters if not m.dead]

    def nearest_monster(self, x, y, maxd):
        best, bd = None, maxd
        for m in self.cur.monsters:
            if m.dead:
                continue
            d = math.hypot(m.x - x, m.y - y)
            if d < bd:
                best, bd = m, d
        return best

    # ------------------------------------------------------------ cập nhật
    def update(self, dt, mv=(0.0, 0.0)):
        p = self.p
        for m in self.messages:
            m[2] -= dt
        self.messages = [m for m in self.messages if m[2] > 0]

        if not p.dead:
            p.atk_cd = max(0.0, p.atk_cd - dt)
            p.potion_cd = max(0.0, p.potion_cd - dt)
            p.buff_t = max(0.0, p.buff_t - dt)
            for i in range(len(p.skill_cd)):
                p.skill_cd[i] = max(0.0, p.skill_cd[i] - dt)
            s = p.stats
            p.hp = min(s["max_hp"], p.hp + s["hp_regen"] * dt)
            p.mp = min(s["max_mp"], p.mp + s["mp_regen"] * dt)
            dx, dy = mv
            n = math.hypot(dx, dy)
            if n > 0:
                dx, dy = dx / n, dy / n
                p.facing = math.atan2(dy, dx)
                self._move(p, dx * s["move"] * dt, dy * s["move"] * dt, PLAYER_R)
            self._check_portals()

        for m in self.cur.monsters:
            self._update_monster(m, dt)
        self._update_effects(dt)

    def _check_portals(self):
        p = self.p
        for portal in self.cur.portals:
            if _in_rect(p.x, p.y, portal["rect"]):
                self.travel(portal["to"], portal["spawn"])
                return

    def travel(self, key, spawn):
        p = self.p
        p.map = key
        p.x, p.y = spawn
        self.cur = self.maps[key]
        self.effects = []
        for m in self.cur.monsters:
            m.aggro = False
        self.say("Đến: %s" % self.cur.name, (180, 220, 255))
        if not self.cur.visited:
            self.cur.visited = True
            if self.cur.sign:
                self.say("Gần lối vào có tấm bia khắc chữ (nhấn E để đọc).", (200, 200, 140))

    # ------------------------------------------------------------ quái vật
    def _update_monster(self, m, dt):
        p = self.p
        if m.dead:
            m.respawn_t -= dt
            if m.respawn_t <= 0:
                m.revive()
            return
        m.cd -= dt
        m.flash -= dt
        if m.burn_t > 0:
            m.burn_t -= dt
            m.burn_acc += dt
            while m.burn_acc >= 0.5 and not m.dead:
                m.burn_acc -= 0.5
                self._damage_monster(m, m.burn_dps * 0.5, color=(255, 150, 60))
            if m.dead:
                return

        dist = math.hypot(p.x - m.x, p.y - m.y)
        home_d = math.hypot(m.home[0] - m.x, m.home[1] - m.y)
        engaged = (not p.dead) and (dist < m.d["aggro"] or m.aggro) and home_d < LEASH
        if m.aggro and (p.dead or home_d >= LEASH):
            m.aggro = False
        reach = m.radius + PLAYER_R + m.d["range"]
        phase2 = m.hp < m.max_hp * 0.5

        if engaged:
            if m.d.get("shock"):
                self._boss_shock(m, dt, dist)
            if dist > reach * 0.9:
                step = m.speed * (1.25 if phase2 and m.d.get("shock") else 1.0) * dt
                ang = math.atan2(p.y - m.y, p.x - m.x)
                self._move(m, math.cos(ang) * step, math.sin(ang) * step, m.radius * 0.8)
            elif m.cd <= 0:
                m.cd = m.d["cd"] * (0.7 if phase2 else 1.0)
                self._damage_player(m.atk * self.rng.uniform(0.9, 1.1))
        else:
            if home_d > 30 and not m.aggro:
                ang = math.atan2(m.home[1] - m.y, m.home[0] - m.x)
                self._move(m, math.cos(ang) * m.speed * 0.8 * dt, math.sin(ang) * m.speed * 0.8 * dt,
                           m.radius * 0.8)
                m.hp = min(m.max_hp, m.hp + m.max_hp * 0.15 * dt)
            else:
                m.wander_t -= dt
                if m.wander_t <= 0:
                    m.wander_t = self.rng.uniform(2.0, 4.0)
                    m.wander = (m.home[0] + self.rng.uniform(-70, 70), m.home[1] + self.rng.uniform(-70, 70))
                wx, wy = m.wander
                dd = math.hypot(wx - m.x, wy - m.y)
                if dd > 6:
                    self._move(m, (wx - m.x) / dd * m.speed * 0.35 * dt, (wy - m.y) / dd * m.speed * 0.35 * dt,
                               m.radius * 0.8)

    def _boss_shock(self, m, dt, dist):
        if m.shock_t > 0:
            m.shock_t -= dt
            if m.shock_t <= 0:
                self.effects.append({"type": "ring", "x": m.x, "y": m.y, "r": SHOCK_R, "ttl": 0.35, "max": 0.35,
                                     "color": (255, 90, 60)})
                if math.hypot(self.p.x - m.x, self.p.y - m.y) <= SHOCK_R + PLAYER_R:
                    self._damage_player(m.atk * 1.6)
                m.shock_cd = 6.0
        else:
            m.shock_cd -= dt
            if m.shock_cd <= 0:
                m.shock_t = 1.1
                self.say("%s tích lực, mau thoát khỏi vòng đỏ!" % m.name, (255, 120, 100), 3.0)

    # ---------------------------------------------------------- sát thương
    def _damage_player(self, raw):
        p = self.p
        if p.dead:
            return
        s = p.stats
        if self.rng.random() * 100 < s["dodge"]:
            self._text(p.x, p.y - 20, "Né", (200, 200, 255))
            return
        dmg = max(1.0, raw - s["def"] * 0.5) * (1 - s["resist"] / 100.0)
        if p.buff_t > 0:
            dmg *= 1 - D.SKILLS[2]["reduce"]
        p.hp -= dmg
        self.flash_t = 0.15
        self._text(p.x, p.y - 20, "-%d" % round(dmg), (255, 90, 90))
        if p.hp <= 0:
            p.hp = 0
            p.dead = True
            for m in self.cur.monsters:
                m.aggro = False
            self.say("Bạn đã ngã xuống. Nhấn R để hồi sinh tại Đại Trúc Phong.", (255, 120, 120), 12.0)

    def respawn(self):
        p = self.p
        if not p.dead:
            return
        p.dead = False
        p.hp = p.stats["max_hp"] * 0.5
        p.mp = p.stats["max_mp"]
        p.buff_t = 0.0
        key = D.HUB_MAP
        p.map = key
        p.x, p.y = D.MAPS[key]["start"]
        self.cur = self.maps[key]
        self.effects = []
        self.say("Bạn tỉnh lại ở Đại Trúc Phong.", (180, 220, 255))

    def _heal(self, amount):
        p = self.p
        p.hp = min(p.stats["max_hp"], p.hp + amount)

    def _damage_monster(self, m, dmg, crit=False, color=None):
        if m.dead:
            return
        m.hp -= dmg
        m.aggro = True
        m.flash = 0.1
        if color is None:
            color = (255, 230, 90) if crit else (255, 255, 255)
        self._text(m.x, m.y - m.radius - 8, ("%d!" % round(dmg)) if crit else "%d" % round(dmg), color)
        if m.hp <= 0:
            m.hp = 0
            self._kill(m)

    def _hit_monster(self, m, mult, proc=True):
        """Người chơi đánh trúng quái: tính sát thương, hút máu và hiệu ứng đồ Tím."""
        p = self.p
        s = p.stats
        dmg = max(1.0, s["atk"] * mult - m.defn * 0.5) * self.rng.uniform(0.92, 1.08)
        crit = self.rng.random() * 100 < s["crit"]
        if crit:
            dmg *= s["crit_dmg"] / 100.0
        if s["lifesteal"]:
            self._heal(dmg * s["lifesteal"] / 100.0)
        sp = s["specials"]
        if proc and sp:
            if "huyet_dan" in sp:
                self._heal(dmg * sp["huyet_dan"] / 100.0)
            if "hoa_diem" in sp and not m.dead:
                m.burn_t = 3.0
                m.burn_dps = s["atk"] * sp["hoa_diem"] / 100.0 / 3.0
        self._damage_monster(m, dmg, crit)
        if proc and "loi_phat" in sp and self.rng.random() < 0.10:
            self.effects.append({"type": "bolt", "x": m.x, "y": m.y, "ttl": 0.3, "max": 0.3})
            bolt = s["atk"] * sp["loi_phat"] / 100.0
            for other in list(self.cur.monsters):
                if not other.dead and math.hypot(other.x - m.x, other.y - m.y) <= 90 + other.radius:
                    self._damage_monster(other, max(1.0, bolt - other.defn * 0.5), color=(200, 160, 255))

    # ------------------------------------------------------------- hạ quái
    def _kill(self, m):
        p = self.p
        m.dead = True
        m.respawn_t = m.d["respawn"]
        m.aggro = False
        m.burn_t = 0.0
        p.kills += 1

        for msg in p.gain_exp(m.d["exp"]):
            if msg.startswith("LÊN CẤP") or msg.startswith("Học"):
                self.say(msg, (255, 235, 120), 9.0)
        lo, hi = m.d["gold"]
        g = self.rng.randint(lo, hi)
        p.gold += g

        drop = loot.roll_drops(m.kind, m.level, p.stats["luck"], p.pity, self.rng)
        if m.kind in (D.BOSS, D.BHK):
            self.say("Hạ %s! (+%d vàng)" % (m.name, g), (255, 200, 120), 8.0)
        for it in drop.items:
            notes = p.receive_item(it)
            if it.tier >= 1 or not p.auto_sell_white:
                self.say("Nhận %s [%s]" % (it.display_name(), D.TIER_NAMES[it.tier]), D.TIER_COLORS[it.tier], 8.0)
            for n in notes:
                self.say(n, (200, 180, 120))
        for gem, n in drop.gems.items():
            if n:
                p.gems[gem] += n
                self.say("Nhận %d %s" % (n, D.GEM_NAMES[gem]), D.GEM_COLORS[gem], 6.0)
        if drop.forced:
            self.say("Bảo hiểm kích hoạt: chắc chắn rơi đồ %s!" % " và ".join(drop.forced), (255, 220, 140), 8.0)

        for qid in p.quests.on_event("kill", m.mid):
            self.say("Nhiệm vụ '%s' đã đủ mục tiêu. Về trả nhiệm vụ!" % D.QUEST_BY_ID[qid]["name"],
                     (140, 230, 255), 9.0)

    # --------------------------------------------------- hành động người chơi
    def player_attack(self):
        p = self.p
        if p.dead or p.atk_cd > 0:
            return False
        p.atk_cd = p.stats["atk_interval"]
        near = self.nearest_monster(p.x, p.y, 120)
        if near:
            p.facing = math.atan2(near.y - p.y, near.x - p.x)
        self.effects.append({"type": "slash", "x": p.x, "y": p.y, "a": p.facing, "ttl": 0.16, "max": 0.16})
        for m in list(self.cur.monsters):
            if m.dead:
                continue
            d = math.hypot(m.x - p.x, m.y - p.y)
            if d <= MELEE_RANGE + m.radius:
                ang = math.atan2(m.y - p.y, m.x - p.x)
                if d < m.radius + 18 or _angle_diff(ang, p.facing) <= MELEE_ARC:
                    self._hit_monster(m, 1.0)
        return True

    def cast(self, idx):
        p = self.p
        if p.dead or idx >= len(D.SKILLS):
            return False
        sk = D.SKILLS[idx]
        if p.level < sk["unlock"]:
            self.say("%s mở ở cấp %d." % (sk["name"], sk["unlock"]), (200, 200, 200), 3.0)
            return False
        if p.skill_cd[idx] > 0:
            return False
        if p.mp < sk["mp"]:
            self.say("Không đủ pháp lực.", (150, 170, 255), 2.0)
            return False
        p.mp -= sk["mp"]
        p.skill_cd[idx] = sk["cd"] * (1 - p.stats["cdr"] / 100.0)
        t = sk["type"]
        if t == "proj":
            near = self.nearest_monster(p.x, p.y, 380)
            if near:
                p.facing = math.atan2(near.y - p.y, near.x - p.x)
            self.effects.append({"type": "proj", "x": p.x, "y": p.y, "vx": math.cos(p.facing) * sk["speed"],
                                 "vy": math.sin(p.facing) * sk["speed"], "left": sk["range"], "mult": sk["mult"],
                                 "ttl": 5.0})
        elif t == "aoe":
            self.effects.append({"type": "ring", "x": p.x, "y": p.y, "r": sk["radius"], "ttl": 0.4, "max": 0.4,
                                 "color": (170, 150, 255)})
            for m in list(self.cur.monsters):
                if not m.dead and math.hypot(m.x - p.x, m.y - p.y) <= sk["radius"] + m.radius:
                    self._hit_monster(m, sk["mult"])
        elif t == "buff":
            self._heal(p.stats["max_hp"] * sk["heal"])
            p.buff_t = sk["dur"]
            self.effects.append({"type": "ring", "x": p.x, "y": p.y, "r": 50, "ttl": 0.5, "max": 0.5,
                                 "color": (255, 230, 120)})
        elif t == "zone":
            zx = p.x + math.cos(p.facing) * sk["dist"]
            zy = p.y + math.sin(p.facing) * sk["dist"]
            self.effects.append({"type": "zone", "x": zx, "y": zy, "r": sk["radius"], "ttl": sk["dur"],
                                 "max": sk["dur"], "tick": 0.0, "mult": sk["mult"]})
        return True

    def use_potion(self):
        p = self.p
        if p.dead or p.potions <= 0 or p.potion_cd > 0:
            return False
        if p.hp >= p.stats["max_hp"] - 1:
            return False
        p.potions -= 1
        p.potion_cd = D.POTION_CD
        self._heal(p.stats["max_hp"] * D.POTION_HEAL)
        self._text(p.x, p.y - 20, "+HP", (120, 255, 140))
        return True

    # ------------------------------------------------------------ tương tác
    def nearby_npc(self):
        p = self.p
        for n in self.cur.npcs:
            if math.hypot(n["x"] - p.x, n["y"] - p.y) < 80:
                return n
        return None

    def nearby_switch(self):
        p = self.p
        for i, s in enumerate(self.cur.switches):
            if math.hypot(s["x"] - p.x, s["y"] - p.y) < 60:
                return i
        return None

    def near_sign(self):
        s = self.cur.sign
        return bool(s) and math.hypot(s["x"] - self.p.x, s["y"] - self.p.y) < 90

    def interact(self):
        """Phím E. Trả về ('npc', npc) nếu cần mở hộp thoại, ngược lại None."""
        if self.p.dead:
            return None
        n = self.nearby_npc()
        if n:
            for qid in self.p.quests.on_event("talk", n["id"]):
                self.say("Nhiệm vụ '%s' đã đủ mục tiêu. Về trả nhiệm vụ!" % D.QUEST_BY_ID[qid]["name"],
                         (140, 230, 255), 9.0)
            return ("npc", n)
        i = self.nearby_switch()
        if i is not None:
            self.press_switch(i)
            return None
        if self.near_sign():
            self.say(self.cur.sign["text"], (230, 220, 150), 10.0)
        return None

    def press_switch(self, i):
        m = self.cur
        if m.solved:
            self.say("Cửa đá đã mở.", (200, 200, 200), 3.0)
            return
        if i in m.switch_progress:
            self.say("Công tắc này đã bật.", (200, 200, 200), 3.0)
            return
        want = m.switch_order[len(m.switch_progress)]
        if i == want:
            m.switch_progress.append(i)
            m.switches[i]["on"] = True
            self.say("Công tắc %s sáng lên." % m.switches[i]["name"], m.switches[i]["color"], 4.0)
            if len(m.switch_progress) == len(m.switch_order):
                m.solved = True
                if m.door in m.obstacles:
                    m.obstacles.remove(m.door)
                self.say("Cửa đá nặng nề mở ra! Phòng boss ở phía trên.", (255, 230, 140), 9.0)
                self.effects.append({"type": "ring", "x": m.door["rect"][0] + 60, "y": m.door["rect"][1] + 12,
                                     "r": 90, "ttl": 0.6, "max": 0.6, "color": (255, 230, 140)})
                for qid in self.p.quests.on_event("puzzle", m.key):
                    self.say("Nhiệm vụ '%s' đã đủ mục tiêu. Về trả nhiệm vụ!" % D.QUEST_BY_ID[qid]["name"],
                             (140, 230, 255), 9.0)
        else:
            m.switch_progress = []
            for s in m.switches:
                s["on"] = False
            self.say("Sai thứ tự! Các công tắc tắt lại.", (255, 130, 110), 5.0)

    def notify_quest_accepted(self, qid):
        """Nếu mục tiêu của nhiệm vụ đã đạt sẵn (ví dụ cửa đá đã mở) thì ghi nhận ngay."""
        obj = D.QUEST_BY_ID[qid]["obj"]
        if obj["type"] == "puzzle" and self.maps[obj["target"]].solved:
            for q in self.p.quests.on_event("puzzle", obj["target"]):
                self.say("Nhiệm vụ '%s' đã đủ mục tiêu. Về trả nhiệm vụ!" % D.QUEST_BY_ID[q]["name"],
                         (140, 230, 255), 9.0)

    # --------------------------------------------------------- hiệu ứng
    def _update_effects(self, dt):
        keep = []
        for e in self.effects:
            e["ttl"] -= dt
            t = e["type"]
            if t == "proj":
                step = math.hypot(e["vx"], e["vy"]) * dt
                e["x"] += e["vx"] * dt
                e["y"] += e["vy"] * dt
                e["left"] -= step
                hit = False
                for m in self.cur.monsters:
                    if not m.dead and math.hypot(m.x - e["x"], m.y - e["y"]) <= m.radius + 9:
                        self._hit_monster(m, e["mult"])
                        hit = True
                        break
                if hit or e["left"] <= 0 or self._blocked(e["x"], e["y"], 4):
                    continue
            elif t == "zone":
                e["tick"] -= dt
                if e["tick"] <= 0:
                    e["tick"] = 0.5
                    for m in list(self.cur.monsters):
                        if not m.dead and math.hypot(m.x - e["x"], m.y - e["y"]) <= e["r"] + m.radius:
                            self._hit_monster(m, e["mult"], proc=False)
            if e["ttl"] > 0:
                keep.append(e)
        self.effects = keep

        for tx in self.texts:
            tx["ttl"] -= dt
            tx["y"] -= 28 * dt
        self.texts = [tx for tx in self.texts if tx["ttl"] > 0]
        self.flash_t = max(0.0, self.flash_t - dt)
