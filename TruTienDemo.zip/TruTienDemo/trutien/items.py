# -*- coding: utf-8 -*-
"""Trang bị: sinh ngẫu nhiên, tính chỉ số, nâng cấp +n."""
import itertools

from . import data as D

_uid_counter = itertools.count(1)


def _bump_uid(uid):
    """Sau khi tải save, đảm bảo uid mới không trùng uid cũ."""
    global _uid_counter
    nxt = next(_uid_counter)
    _uid_counter = itertools.count(max(nxt, uid + 1))


class Item:
    def __init__(self, name, slot, tier, ilvl, base, affixes, special=None, plus=0, uid=None):
        self.uid = uid if uid is not None else next(_uid_counter)
        self.name = name
        self.slot = slot
        self.tier = tier
        self.ilvl = ilvl
        self.base = dict(base)                         # {"atk": 6.0, ...}
        self.affixes = [(k, v) for k, v in affixes]    # [("crit", 3.2), ...]
        self.special = special                         # chỉ đồ Tím
        self.plus = plus

    # ------------------------------------------------------------- chỉ số
    def factor(self):
        return 1.0 + D.UPGRADE_RATE[self.tier] * self.plus

    def stats(self):
        """Tổng chỉ số của món đồ sau khi tính cấp +n."""
        f = self.factor()
        out = {}
        for k, v in self.base.items():
            out[k] = out.get(k, 0.0) + v * f
        for k, v in self.affixes:
            out[k] = out.get(k, 0.0) + v * f
        return out

    def special_value(self):
        if not self.special:
            return 0.0
        base = D.SPECIALS[self.special][2]
        return base * (1.0 + D.SPECIAL_STEP * (self.plus // 3))

    def special_text(self):
        if not self.special:
            return ""
        name, desc, _ = D.SPECIALS[self.special]
        return "%s: %s" % (name, desc.format(x=self.special_value()))

    def display_name(self):
        return self.name + (" +%d" % self.plus if self.plus else "")

    def sell_price(self):
        p = D.SELL_BASE[self.tier] * (1 + 0.3 * (self.ilvl - 1)) * (1 + 0.1 * self.plus)
        return max(1, int(p))

    # ---------------------------------------------------------- mô tả chữ
    def lines(self):
        """Danh sách (chữ, màu hoặc None) để vẽ tooltip."""
        out = [(self.display_name(), D.TIER_COLORS[self.tier])]
        out.append(("%s · %s · Cấp vật phẩm %d" % (D.TIER_NAMES[self.tier], D.SLOT_NAMES[self.slot], self.ilvl), None))
        f = self.factor()
        for k, v in self.base.items():
            out.append(("%s +%s" % (D.STAT_LABELS[k], _fmt(v * f)), (230, 230, 230)))
        for k, v in self.affixes:
            suffix = D.AFFIXES[k][3]
            tail = suffix if suffix == "%" else " " + suffix
            out.append(("%s +%s%s" % (D.STAT_LABELS[k], _fmt(v * f), tail), (150, 220, 255)))
        if self.special:
            out.append((self.special_text(), D.TIER_COLORS[3]))
        out.append(("Giá bán: %d vàng" % self.sell_price(), (200, 180, 120)))
        return out

    # ------------------------------------------------------------ lưu/tải
    def to_dict(self):
        return {"uid": self.uid, "name": self.name, "slot": self.slot, "tier": self.tier, "ilvl": self.ilvl,
                "base": self.base, "affixes": [[k, v] for k, v in self.affixes],
                "special": self.special, "plus": self.plus}

    @staticmethod
    def from_dict(d):
        it = Item(d["name"], d["slot"], d["tier"], d["ilvl"], d["base"], d["affixes"],
                  d.get("special"), d.get("plus", 0), d.get("uid"))
        _bump_uid(it.uid)
        return it


def _fmt(v):
    return ("%.1f" % v).rstrip("0").rstrip(".") if abs(v - round(v)) > 1e-9 else "%d" % round(v)


def generate(tier, ilvl, rng, slot=None):
    """Sinh một món đồ ngẫu nhiên theo cấp Trắng/Xanh/Vàng/Tím."""
    slot = slot or rng.choice(D.SLOTS)
    mult = D.TIER_BASE_MULT[tier] * (1 + D.ILVL_BASE_GROWTH * (ilvl - 1))
    base = {k: round(v * mult, 1) for k, v in D.BASE_STATS[slot].items()}

    lo_n, hi_n = D.AFFIX_COUNT[tier]
    n = rng.randint(lo_n, hi_n)
    affixes = []
    if n:
        for key in rng.sample(list(D.AFFIXES), n):      # không trùng dòng
            _, lo, hi, _ = D.AFFIXES[key]
            r = rng.random()
            if tier == 3:
                r = 0.5 + 0.5 * r                        # Tím luôn roll nửa trên của khoảng
            v = (lo + (hi - lo) * r) * D.AFFIX_TIER_MULT[tier]
            affixes.append((key, round(v, 1)))

    special = rng.choice(list(D.SPECIALS)) if tier == 3 else None
    if tier == 3:
        name = rng.choice(D.LEGEND_NAMES[slot])
    else:
        name = D.TIER_PREFIX[tier] + rng.choice(D.BASE_NAMES[slot])
    return Item(name, slot, tier, ilvl, base, affixes, special)
