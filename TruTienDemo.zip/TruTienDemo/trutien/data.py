# -*- coding: utf-8 -*-
"""Toàn bộ số liệu của game. Muốn cân bằng: sửa ở đây, không cần động vào code."""

# ----------------------------------------------------------------- loại quái
QT, TA, BOSS, BHK = "QT", "TA", "BOSS", "BHK"
KILL_NAMES = {QT: "Quái thường", TA: "Tinh anh", BOSS: "Boss", BHK: "Boss hoàng kim"}

# ------------------------------------------------------------ cấp trang bị
TIER_NAMES = ["Trắng", "Xanh", "Vàng", "Tím"]
TIER_COLORS = [(235, 235, 235), (95, 215, 115), (250, 210, 70), (190, 110, 245)]

# Tỉ lệ rơi trang bị: cấp -> loại quái -> (xác suất, (số món tối thiểu, tối đa))
# Trắng: bạn ghi 50–70% cho quái thường; tinh anh/boss mình giả định như quái thường.
EQUIP_DROP = {
    0: {QT: (0.60, (1, 1)), TA: (0.60, (1, 1)), BOSS: (0.60, (1, 1)), BHK: (0.60, (1, 1))},
    1: {QT: (0.10, (1, 1)), TA: (0.50, (1, 1)), BOSS: (1.00, (2, 5)), BHK: (1.00, (2, 5))},
    2: {QT: (0.05, (1, 1)), TA: (0.15, (1, 1)), BOSS: (0.50, (1, 2)), BHK: (0.50, (1, 2))},
    3: {QT: (0.001, (1, 1)), TA: (0.01, (1, 1)), BOSS: (0.20, (1, 1)), BHK: (1.00, (1, 2))},
}
# Số dòng chỉ số tăng thêm theo cấp
AFFIX_COUNT = {0: (0, 0), 1: (1, 3), 2: (4, 6), 3: (6, 9)}

# Bảo hiểm: sau bao nhiêu "điểm quái thường" không ra thì lần sau chắc chắn ra
PITY = {2: 60, 3: 1500}          # 2 = Vàng, 3 = Tím
PITY_WEIGHT = {QT: 1, TA: 10}    # tinh anh tính bằng 10 quái thường

# ------------------------------------------------------------------ ngọc
GEM_KINDS = ["white", "gold", "purple"]
GEM_NAMES = {"white": "Ngọc Trắng", "gold": "Ngọc Vàng", "purple": "Ngọc Tím"}
GEM_COLORS = {"white": (235, 235, 235), "gold": (250, 210, 70), "purple": (190, 110, 245)}

# Tỉ lệ rơi ngọc: loại ngọc -> loại quái -> (xác suất, (min, max))
GEM_DROP = {
    "white": {QT: (0.10, (1, 1)), TA: (0.30, (1, 1)), BOSS: (0.95, (1, 3)), BHK: (1.00, (3, 5))},
    "gold": {QT: (0.05, (1, 1)), TA: (0.15, (1, 1)), BOSS: (0.80, (1, 2)), BHK: (1.00, (2, 4))},
    "purple": {QT: (0.001, (1, 1)), TA: (0.05, (1, 1)), BOSS: (0.40, (1, 2)), BHK: (1.00, (1, 2))},
}

MAX_PLUS = 9
# Số ngọc cần để lên từng cấp (phần tử i = lên từ +i sang +i+1)
UPGRADE_COST = {
    "white": [1, 1, 1, 2, 2, 2, 3, 3, 3],   # tổng 18
    "gold": [1, 1, 1, 1, 2, 2, 2, 2, 3],    # tổng 15
    "purple": [1] * 9,                       # tổng 9
}
# Ngọc nào nâng được cấp đồ nào (0 Trắng, 1 Xanh, 2 Vàng, 3 Tím)
UPGRADE_ALLOWED = {"white": (0, 1), "gold": (1, 2), "purple": (3,)}
# Mỗi cấp + tăng bao nhiêu % chỉ số cơ bản và các dòng thuộc tính
UPGRADE_RATE = {0: 0.05, 1: 0.05, 2: 0.05, 3: 0.06}
# Đổi ngọc: (ngọc nguồn, số lượng nguồn) -> ngọc đích (1 viên)
EXCHANGE = {"white": ("gold", 3), "gold": ("purple", 3)}

# ------------------------------------------------------------ trang bị
SLOTS = ["weapon", "helm", "armor", "boots", "ring", "fabao"]
SLOT_NAMES = {"weapon": "Vũ khí", "helm": "Mũ", "armor": "Áo", "boots": "Giày",
              "ring": "Nhẫn", "fabao": "Pháp bảo"}
BASE_NAMES = {
    "weapon": ["Kiếm Sắt", "Côn Gỗ", "Trượng Trúc"],
    "helm": ["Mão Vải", "Khăn Đạo Sĩ"],
    "armor": ["Đạo Bào", "Áo Vải Thô"],
    "boots": ["Giày Cỏ", "Ủng Da"],
    "ring": ["Nhẫn Đồng", "Nhẫn Ngọc Thô"],
    "fabao": ["Ngọc Bội", "Linh Phù"],
}
TIER_PREFIX = {0: "", 1: "Tinh Luyện ", 2: "Hoàng Kim ", 3: ""}
# Tên đồ Tím (lấy cảm hứng từ pháp bảo trong truyện)
LEGEND_NAMES = {
    "weapon": ["Thiêu Hỏa Côn", "Trảm Long Kiếm", "Thiên Gia Thần Kiếm"],
    "helm": ["Huyền Thanh Mão"],
    "armor": ["Thanh Vân Đạo Bào"],
    "boots": ["Phi Vân Ngoa"],
    "ring": ["Phệ Huyết Giới"],
    "fabao": ["Hổ Phách Chu Lăng", "Hợp Hoan Linh", "Phệ Huyết Châu", "Huyền Hỏa Giám"],
}
BASE_STATS = {   # chỉ số cơ bản ở item level 1
    "weapon": {"atk": 6},
    "helm": {"def": 2, "hp": 15},
    "armor": {"def": 4, "hp": 25},
    "boots": {"def": 1, "hp": 10},
    "ring": {"atk": 2, "mp": 8},
    "fabao": {"atk": 3, "mp": 15},
}
TIER_BASE_MULT = [1.0, 1.1, 1.25, 1.5]
ILVL_BASE_GROWTH = 0.35

FLAT_KEYS = ("atk", "def", "hp", "mp")
# 16 dòng chỉ số tăng thêm: khoá -> (nhãn, thấp, cao, hậu tố) ở cấp Xanh
AFFIXES = {
    "hp_pct": ("Sinh Lực", 2, 6, "%"),
    "mp_pct": ("Pháp Lực", 2, 6, "%"),
    "atk_pct": ("Công Kích", 2, 6, "%"),
    "def_pct": ("Phòng Ngự", 2, 6, "%"),
    "move_speed": ("Tốc Chạy", 1, 4, "%"),
    "atk_speed": ("Tốc Đánh", 2, 6, "%"),
    "crit": ("Chí Mạng", 1, 4, "%"),
    "crit_dmg": ("Sát Thương Chí Mạng", 4, 12, "%"),
    "dodge": ("Né Tránh", 1, 4, "%"),
    "hp_regen": ("Hồi Sinh Lực", 0.2, 0.8, "/giây"),
    "mp_regen": ("Hồi Pháp Lực", 0.2, 0.8, "/giây"),
    "lifesteal": ("Hút Máu", 1, 3, "%"),
    "exp_bonus": ("Ngộ Tính (EXP)", 3, 8, "%"),
    "luck": ("Phúc Duyên (rơi đồ)", 2, 6, "%"),
    "resist": ("Kháng Sát Thương", 2, 6, "%"),
    "cdr": ("Giảm Hồi Chiêu", 2, 5, "%"),
}
AFFIX_TIER_MULT = {1: 1.0, 2: 1.35, 3: 1.8}   # Tím mạnh hơn mỗi dòng
LUCK_CAP = 25      # Phúc Duyên tối đa +25% (tương đối) cho tỉ lệ rơi đồ Xanh/Vàng/Tím
RESIST_CAP = 60
CDR_CAP = 40

STAT_LABELS = {"atk": "Công Kích", "def": "Phòng Ngự", "hp": "Sinh Lực", "mp": "Pháp Lực"}
for _k, (_n, _a, _b, _s) in AFFIXES.items():
    STAT_LABELS[_k] = _n

# Hiệu ứng đặc biệt của đồ Tím: khoá -> (tên, mô tả có {x}, giá trị cơ bản)
SPECIALS = {
    "loi_phat": ("Lôi Phạt", "10% khi đánh trúng: sét giáng {x:.0f}% Công Kích lên quanh mục tiêu", 150),
    "huyet_dan": ("Huyết Dẫn", "Hút thêm {x:.1f}% sát thương thành sinh lực", 4),
    "hoa_diem": ("Hỏa Diễm", "Đòn đánh gây thiêu đốt {x:.0f}% Công Kích trong 3 giây", 60),
}
# Hiệu ứng đặc biệt mạnh lên ở +3, +6, +9: hệ số = 1 + 0.5 * (plus // 3)
SPECIAL_STEP = 0.5

SELL_BASE = [3, 12, 45, 160]
INVENTORY_CAP = 80
POTION_PRICE = 30
POTION_MAX = 20
POTION_HEAL = 0.40
POTION_CD = 4.0

# -------------------------------------------------------- cấp độ nhân vật
LEVEL_CAP = 20            # Ngọc Thanh Cảnh: cấp 1–20


def exp_to_next(level):
    return int(30 * level ** 1.5)


def realm_name(level):
    return "Ngọc Thanh Cảnh – Tầng %d" % level if level <= 20 else "Thượng Thanh Cảnh"


def base_stats_for_level(level):
    return {
        "hp": 100 + 22 * (level - 1),
        "mp": 50 + 8 * (level - 1),
        "atk": 10 + 3 * (level - 1),
        "def": 3 + 1.5 * (level - 1),
    }


# ------------------------------------------------------------- kỹ năng
# unlock: cấp mở khoá. type: proj (phi tiêu), aoe (quanh người), buff (hồi + giảm sát thương), zone (vùng lửa)
SKILLS = [
    {"id": "phi_cham", "name": "Ngự Kiếm Phi Trảm", "path": "Đạo", "key": "1", "unlock": 1,
     "mp": 12, "cd": 2.5, "type": "proj", "mult": 2.0, "speed": 460, "range": 460,
     "desc": "Phóng kiếm khí thẳng phía trước."},
    {"id": "ngu_loi", "name": "Ngự Lôi", "path": "Đạo", "key": "2", "unlock": 3,
     "mp": 20, "cd": 6.0, "type": "aoe", "mult": 2.6, "radius": 125,
     "desc": "Sét giáng quanh người, sát thương diện rộng."},
    {"id": "bat_nha", "name": "Bát Nhã Hộ Thể", "path": "Phật", "key": "3", "unlock": 5,
     "mp": 25, "cd": 14.0, "type": "buff", "heal": 0.35, "reduce": 0.5, "dur": 5.0,
     "desc": "Hồi 35% sinh lực, giảm một nửa sát thương nhận trong 5 giây."},
    {"id": "huyen_hoa", "name": "Huyền Hỏa Trận", "path": "Hỏa", "key": "4", "unlock": 8,
     "mp": 30, "cd": 12.0, "type": "zone", "mult": 0.9, "radius": 105, "dur": 5.0, "dist": 150,
     "desc": "Tạo vùng lửa phía trước, thiêu đốt kẻ đứng trong đó."},
]

# ------------------------------------------------------------------ quái
# exp, gold, kind, level... Số liệu thô, cần cân bằng thêm.
MONSTERS = {
    "soi_rung": {"name": "Sói Rừng", "level": 2, "hp": 45, "atk": 9, "def": 1, "speed": 92,
                 "kind": QT, "exp": 12, "gold": (2, 5), "color": (150, 150, 165), "radius": 13,
                 "aggro": 170, "range": 20, "cd": 1.1, "respawn": 20},
    "ran_doc": {"name": "Rắn Độc", "level": 3, "hp": 60, "atk": 12, "def": 1, "speed": 105,
                "kind": QT, "exp": 16, "gold": (3, 7), "color": (90, 170, 80), "radius": 12,
                "aggro": 160, "range": 22, "cd": 0.95, "respawn": 20},
    "doi_lon": {"name": "Dơi Lớn", "level": 5, "hp": 90, "atk": 16, "def": 2, "speed": 135,
                "kind": QT, "exp": 24, "gold": (5, 10), "color": (110, 70, 130), "radius": 12,
                "aggro": 220, "range": 20, "cd": 1.0, "respawn": 20},
    "soi_thu_linh": {"name": "Hắc Lang Thủ Lĩnh", "level": 4, "hp": 320, "atk": 17, "def": 3, "speed": 100,
                     "kind": TA, "exp": 120, "gold": (20, 35), "color": (60, 60, 75), "radius": 20,
                     "aggro": 220, "range": 26, "cd": 1.0, "respawn": 60},
    "soi_vuong": {"name": "Sói Vương", "level": 6, "hp": 1300, "atk": 26, "def": 5, "speed": 95,
                  "kind": BOSS, "exp": 400, "gold": (80, 130), "color": (200, 200, 215), "radius": 30,
                  "aggro": 260, "range": 34, "cd": 1.3, "respawn": 90},
    "yeu_thu_u_coc": {"name": "Yêu Thú U Cốc", "level": 8, "hp": 2600, "atk": 32, "def": 8, "speed": 88,
                      "kind": BHK, "exp": 1200, "gold": (200, 320), "color": (170, 40, 50), "radius": 38,
                      "aggro": 300, "range": 42, "cd": 1.6, "respawn": 120, "shock": True},
}

# ----------------------------------------------------------------- bản đồ
# obstacles viết tay: (x, y, w, h, loại). Cây ở rừng sinh ngẫu nhiên.
MAPS = {
    "dai_truc_phong": {
        "name": "Đại Trúc Phong", "w": 1200, "h": 800, "bg": (44, 96, 60), "safe": True,
        "obstacles": [(160, 120, 200, 120, "house"), (820, 140, 220, 130, "house"),
                      (160, 560, 180, 110, "house"), (880, 560, 160, 110, "house")],
        "trees": 28, "tree_seed": 11,
        "portals": [{"rect": (1160, 330, 40, 140), "to": "rung_truc", "spawn": (90, 560), "label": "Rừng Trúc →"}],
        "npcs": [
            {"id": "dien_bat_dich", "name": "Điền Bất Dịch", "x": 520, "y": 330, "color": (230, 170, 60)},
            {"id": "thuong_nhan", "name": "Thương Nhân", "x": 700, "y": 460, "color": (90, 170, 230)},
        ],
        "spawns": [],
        "start": (600, 420),
    },
    "rung_truc": {
        "name": "Rừng Trúc", "w": 1800, "h": 1100, "bg": (30, 78, 48), "safe": False,
        "obstacles": [],
        "trees": 70, "tree_seed": 23,
        "portals": [
            {"rect": (0, 480, 40, 160), "to": "dai_truc_phong", "spawn": (1090, 400), "label": "← Đại Trúc Phong"},
            {"rect": (800, 0, 200, 40), "to": "u_coc", "spawn": (700, 800), "label": "U Cốc ↑"},
        ],
        "npcs": [],
        "spawns": [("soi_rung", 9), ("ran_doc", 7), ("soi_thu_linh", 1), ("soi_vuong", 1)],
        "fixed_spawns": {"soi_thu_linh": (1300, 400), "soi_vuong": (1500, 850)},
    },
    "u_coc": {
        "name": "U Cốc", "w": 1400, "h": 900, "bg": (34, 30, 48), "safe": False,
        "obstacles": [(0, 410, 640, 24, "wall"), (760, 410, 640, 24, "wall"),
                      (300, 640, 60, 60, "rock"), (1000, 620, 70, 60, "rock"), (180, 520, 50, 50, "rock")],
        "door": (640, 410, 120, 24),
        "trees": 0, "tree_seed": 0,
        "portals": [{"rect": (600, 860, 200, 40), "to": "rung_truc", "spawn": (900, 90), "label": "↓ Rừng Trúc"}],
        "npcs": [],
        "spawns": [("doi_lon", 8), ("yeu_thu_u_coc", 1)],
        "fixed_spawns": {"yeu_thu_u_coc": (700, 190)},
        "regions": {"doi_lon": (120, 480, 1280, 800)},
        # công tắc phải bấm theo đúng thứ tự: Đỏ -> Lục -> Vàng
        "switches": [
            {"x": 200, "y": 640, "color": (225, 70, 70), "name": "Đỏ"},
            {"x": 1220, "y": 560, "color": (80, 200, 100), "name": "Lục"},
            {"x": 700, "y": 520, "color": (240, 210, 70), "name": "Vàng"},
        ],
        "switch_order": [0, 1, 2],
        "sign": {"x": 640, "y": 800, "text": "Cổ khắc: Đỏ → Lục → Vàng. Sai thứ tự thì cửa đá sẽ khóa lại."},
    },
}
HUB_MAP = "dai_truc_phong"

# --------------------------------------------------------------- nhiệm vụ
# status: locked / available / active / ready / done
# objective: talk (nói chuyện với NPC), kill (diệt quái theo id), puzzle (giải đố)
QUESTS = [
    {"id": "m1", "main": True, "name": "Bái sư Đại Trúc Phong", "giver": "dien_bat_dich", "level": 1, "requires": [],
     "desc": "Điền Bất Dịch bảo bạn đi gặp Thương Nhân để sắm đồ trước khi vào rừng.",
     "obj": {"type": "talk", "target": "thuong_nhan", "count": 1, "label": "Gặp Thương Nhân"},
     "reward": {"exp": 80, "gold": 40, "gems": {"white": (2, 2)}}},
    {"id": "m2", "main": True, "name": "Săn Sói Rừng", "giver": "dien_bat_dich", "level": 1, "requires": ["m1"],
     "desc": "Sói rừng quấy phá quanh Đại Trúc Phong. Hạ 6 con ở Rừng Trúc.",
     "obj": {"type": "kill", "target": "soi_rung", "count": 6, "label": "Hạ Sói Rừng"},
     "reward": {"exp": 250, "gold": 90, "gems": {"white": (3, 3)}, "items": [(1, 1)]}},
    {"id": "m3", "main": True, "name": "Vào U Cốc", "giver": "dien_bat_dich", "level": 4, "requires": ["m2"],
     "desc": "Trong U Cốc có yêu thú tác oai. Giải cơ quan, mở cửa đá và hạ nó.",
     "obj": {"type": "kill", "target": "yeu_thu_u_coc", "count": 1, "label": "Hạ Yêu Thú U Cốc"},
     "reward": {"exp": 800, "gold": 250, "gems": {"white": (4, 4), "gold": (2, 3)}, "items": [(2, 1)]}},
    {"id": "s1", "main": False, "name": "Dọn rắn độc", "giver": "dien_bat_dich", "level": 2, "requires": ["m1"],
     "desc": "Rắn độc bò vào vườn thuốc. Hạ 5 con.",
     "obj": {"type": "kill", "target": "ran_doc", "count": 5, "label": "Hạ Rắn Độc"},
     "reward": {"exp": 150, "gold": 60, "gems": {"white": (1, 2)}}},
    {"id": "s2", "main": False, "name": "Săn tinh anh: Hắc Lang", "giver": "thuong_nhan", "level": 3, "requires": ["m2"],
     "desc": "Thương Nhân treo thưởng cho ai hạ được Hắc Lang Thủ Lĩnh.",
     "obj": {"type": "kill", "target": "soi_thu_linh", "count": 1, "label": "Hạ Hắc Lang Thủ Lĩnh"},
     "reward": {"exp": 300, "gold": 120, "gems": {"white": (1, 1), "gold": (1, 1)}, "items": [(1, 1)]}},
    {"id": "s3", "main": False, "name": "Bí cảnh U Cốc: cơ quan", "giver": "thuong_nhan", "level": 4, "requires": ["m2"],
     "desc": "Có người đồn cửa đá trong U Cốc ẩn giấu kho báu. Bật công tắc đúng thứ tự.",
     "obj": {"type": "puzzle", "target": "u_coc", "count": 1, "label": "Mở cửa đá U Cốc"},
     "reward": {"exp": 300, "gold": 100, "gems": {"white": (2, 2), "gold": (1, 2)},
                "gem_chance": {"purple": (0.10, 1)}}},
]
QUEST_BY_ID = {q["id"]: q for q in QUESTS}

NPC_TEXT = {
    "dien_bat_dich": "Đã vào Đại Trúc Phong thì phải chịu khó luyện. Việc nào xong thì quay về đây báo với ta.",
    "thuong_nhan": "Đan dược, ngọc, đồ cũ... ta thu mua hết. Có thứ gì cần đổi thì cứ nói.",
}
