# -*- coding: utf-8 -*-
"""Nhiệm vụ chính và phụ."""
from . import data as D
from . import items as I


class QuestLog:
    """state: {quest_id: {"status": "active"|"ready"|"done", "n": số đã làm}}"""

    def __init__(self):
        self.state = {}

    # --------------------------------------------------------- trạng thái
    def status(self, qid, level):
        s = self.state.get(qid)
        if s:
            return s["status"]
        q = D.QUEST_BY_ID[qid]
        ok = level >= q["level"] and all(self.state.get(r, {}).get("status") == "done" for r in q["requires"])
        return "available" if ok else "locked"

    def progress(self, qid):
        return self.state.get(qid, {}).get("n", 0)

    def active_ids(self):
        return [qid for qid, s in self.state.items() if s["status"] in ("active", "ready")]

    def for_giver(self, npc_id):
        return [q for q in D.QUESTS if q["giver"] == npc_id]

    # --------------------------------------------------------------- hành động
    def accept(self, qid, level):
        if self.status(qid, level) != "available":
            return False
        self.state[qid] = {"status": "active", "n": 0}
        return True

    def on_event(self, kind, target):
        """Gọi khi hạ quái ('kill', id quái), nói chuyện ('talk', id npc), giải đố ('puzzle', id map).
        Trả về danh sách id nhiệm vụ vừa hoàn thành mục tiêu."""
        done = []
        for qid, s in self.state.items():
            if s["status"] != "active":
                continue
            obj = D.QUEST_BY_ID[qid]["obj"]
            if obj["type"] == kind and obj["target"] == target:
                s["n"] = min(obj["count"], s["n"] + 1)
                if s["n"] >= obj["count"]:
                    s["status"] = "ready"
                    done.append(qid)
        return done

    def turn_in(self, qid, player, rng):
        """Trả nhiệm vụ: cộng thưởng cho player. Trả về (ok, danh sách thông báo)."""
        s = self.state.get(qid)
        if not s or s["status"] != "ready":
            return False, []
        q = D.QUEST_BY_ID[qid]
        r = q["reward"]
        msgs = []
        s["status"] = "done"
        if r.get("exp"):
            msgs += player.gain_exp(r["exp"], from_quest=True)
        if r.get("gold"):
            player.gold += r["gold"]
            msgs.append("Nhận %d vàng." % r["gold"])
        gem_got = {}
        for gem, (lo, hi) in r.get("gems", {}).items():
            n = rng.randint(lo, hi)
            gem_got[gem] = gem_got.get(gem, 0) + n
        for gem, (chance, n) in r.get("gem_chance", {}).items():
            if rng.random() < chance:
                gem_got[gem] = gem_got.get(gem, 0) + n
        for gem, n in gem_got.items():
            if n:
                player.gems[gem] += n
                msgs.append("Nhận %d %s." % (n, D.GEM_NAMES[gem]))
        for tier, count in r.get("items", []):
            for _ in range(count):
                it = I.generate(tier, max(1, player.level), rng)
                msgs += player.receive_item(it)
        return True, msgs

    # ------------------------------------------------------------ lưu/tải
    def to_dict(self):
        return {qid: dict(s) for qid, s in self.state.items()}

    @staticmethod
    def from_dict(d):
        ql = QuestLog()
        ql.state = {qid: {"status": s["status"], "n": s.get("n", 0)} for qid, s in d.items()
                    if qid in D.QUEST_BY_ID}
        return ql
