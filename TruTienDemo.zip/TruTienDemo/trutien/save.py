# -*- coding: utf-8 -*-
"""Lưu và tải game (JSON). File save nằm ở thư mục người dùng, không nằm cạnh file .exe."""
import json
import os
from pathlib import Path

from .player import Player


def default_path():
    base = os.environ.get("TRUTIEN_SAVE_DIR")
    folder = Path(base) if base else Path.home() / ".tru_tien_demo"
    return folder / "save.json"


def exists(path=None):
    return Path(path or default_path()).is_file()


def save_game(player, path=None):
    path = Path(path or default_path())
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(player.to_dict(), ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)           # ghi tạm rồi đổi tên để không hỏng save khi bị ngắt giữa chừng


def load_game(path=None):
    path = Path(path or default_path())
    return Player.from_dict(json.loads(path.read_text(encoding="utf-8")))
