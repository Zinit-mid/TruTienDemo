# -*- coding: utf-8 -*-
"""Nâng cấp trang bị bằng ngọc (+0 đến +9, thành công 100%) và đổi ngọc."""
from . import data as D


def can_use(item, gem):
    """Loại ngọc này có nâng được cấp đồ của món này không."""
    return item.tier in D.UPGRADE_ALLOWED[gem]


def next_cost(item, gem):
    """Số ngọc cần để lên cấp kế tiếp, hoặc None nếu đã tối đa."""
    if item.plus >= D.MAX_PLUS:
        return None
    return D.UPGRADE_COST[gem][item.plus]


def upgrade(item, gem, stock):
    """Nâng item thêm 1 cấp bằng ngọc `gem`, trừ vào `stock` (dict). Trả về (ok, thông báo)."""
    if not can_use(item, gem):
        return False, "%s không dùng được cho đồ %s." % (D.GEM_NAMES[gem], D.TIER_NAMES[item.tier])
    cost = next_cost(item, gem)
    if cost is None:
        return False, "Món đồ đã đạt +%d." % D.MAX_PLUS
    if stock.get(gem, 0) < cost:
        return False, "Thiếu ngọc: cần %d %s (đang có %d)." % (cost, D.GEM_NAMES[gem], stock.get(gem, 0))
    stock[gem] -= cost
    item.plus += 1
    return True, "%s lên +%d (tốn %d %s)." % (item.name, item.plus, cost, D.GEM_NAMES[gem])


def exchange(src, stock):
    """Đổi ngọc cấp thấp lấy ngọc cấp cao hơn: 3 trắng = 1 vàng, 3 vàng = 1 tím."""
    if src not in D.EXCHANGE:
        return False, "Ngọc này không đổi lên được nữa."
    dst, need = D.EXCHANGE[src]
    if stock.get(src, 0) < need:
        return False, "Cần %d %s để đổi 1 %s." % (need, D.GEM_NAMES[src], D.GEM_NAMES[dst])
    stock[src] -= need
    stock[dst] = stock.get(dst, 0) + 1
    return True, "Đã đổi %d %s lấy 1 %s." % (need, D.GEM_NAMES[src], D.GEM_NAMES[dst])
