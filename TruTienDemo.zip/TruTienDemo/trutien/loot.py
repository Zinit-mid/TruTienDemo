# -*- coding: utf-8 -*-
"""Hệ rơi đồ và ngọc, có cơ chế bảo hiểm cho đồ Vàng và Tím."""
from . import data as D
from . import items as I


class Drop:
    def __init__(self):
        self.items = []
        self.gems = {"white": 0, "gold": 0, "purple": 0}
        self.forced = []          # tên cấp được bảo hiểm kích hoạt

    def empty(self):
        return not self.items and not any(self.gems.values())


def roll_drops(kind, level, luck, pity, rng):
    """Tung xúc xắc cho một lần hạ quái.

    kind  : D.QT / D.TA / D.BOSS / D.BHK
    level : cấp quái (làm cấp vật phẩm)
    luck  : Phúc Duyên (%), giới hạn D.LUCK_CAP, chỉ tăng tỉ lệ đồ Xanh/Vàng/Tím
    pity  : dict {"gold": n, "purple": n}, được cập nhật tại chỗ
    """
    drop = Drop()
    luck = min(max(luck, 0), D.LUCK_CAP)

    weight = D.PITY_WEIGHT.get(kind, 0)
    if weight:
        pity["gold"] += weight
        pity["purple"] += weight

    for tier in (0, 1, 2, 3):
        chance, (lo, hi) = D.EQUIP_DROP[tier][kind]
        if tier >= 1:
            chance = min(1.0, chance * (1 + luck / 100.0))
        n = rng.randint(lo, hi) if rng.random() < chance else 0

        # Bảo hiểm: chỉ tính trên quái thường / tinh anh
        if tier in (2, 3) and weight and n == 0:
            key = "gold" if tier == 2 else "purple"
            if pity[key] >= D.PITY[tier]:
                n = 1
                drop.forced.append(D.TIER_NAMES[tier])
        if tier in (2, 3) and n > 0:
            pity["gold" if tier == 2 else "purple"] = 0

        for _ in range(n):
            drop.items.append(I.generate(tier, level, rng))

    for gem in D.GEM_KINDS:
        chance, (lo, hi) = D.GEM_DROP[gem][kind]
        if rng.random() < chance:
            drop.gems[gem] += rng.randint(lo, hi)
    return drop
